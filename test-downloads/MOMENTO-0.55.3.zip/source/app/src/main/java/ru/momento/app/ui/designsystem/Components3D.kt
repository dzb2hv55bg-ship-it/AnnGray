package ru.momento.app.ui.designsystem

import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

@Composable
internal fun Vlog3DGlassCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier.vlogGlass(MaterialTheme.shapes.medium, material = MaterialTheme.colorScheme.surfaceContainer)) {
        content()
    }
}

@Composable
internal fun Vlog3DButton(
    onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true,
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.94f else 1f, label = "button depth")
    val material = MaterialTheme.colorScheme
    Button(
        onClick = {
            view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
            onClick()
        },
        modifier = modifier.scale(scale).vlogGlass(
            depth = if (pressed) 2.dp else 7.dp,
            material = if (enabled) material.primaryContainer else material.surfaceContainer
        ),
        enabled = enabled, interactionSource = interaction,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent, disabledContainerColor = Color.Transparent,
            contentColor = material.onPrimaryContainer, disabledContentColor = material.onSurfaceVariant
        ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp)
    ) { content() }
}

@Composable
internal fun Vlog3DIconButton(
    onClick: () -> Unit, description: String, modifier: Modifier = Modifier,
    enabled: Boolean = true, haptic: Boolean = true, content: @Composable () -> Unit
) {
    val view = LocalView.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.94f else 1f, label = "icon depth")
    IconButton(
        onClick = {
            if (haptic) view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
            onClick()
        },
        modifier = modifier.scale(scale).vlogGlass(depth = if (pressed) 2.dp else 8.dp)
            .semantics { contentDescription = description },
        interactionSource = interaction, enabled = enabled
    ) { content() }
}

@Composable
internal fun Vlog3DShutterButton(
    busy: Boolean, paused: Boolean, enabled: Boolean, progress: Float, onClick: () -> Unit
) {
    val diameter by animateDpAsState(if (busy) 28.dp else 58.dp, label = "shutter size")
    val corner by animateDpAsState(if (busy) 8.dp else 30.dp, label = "shutter shape")
    val core = if (paused || !enabled && !busy) Color(0xFF965250) else CameraRecordAccent
    Box(Modifier.size(88.dp), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(
            progress = { progress }, modifier = Modifier.fillMaxSize(), color = CameraRecordAccent,
            trackColor = Color(0x59FFFFFF), strokeWidth = 4.dp
        )
        Vlog3DIconButton(
            onClick = onClick, description = if (busy) "Завершить запись" else "Записать момент",
            modifier = Modifier.size(72.dp), enabled = enabled, haptic = false
        ) {
            Box(Modifier.size(diameter).clip(RoundedCornerShape(corner))
                .background(Brush.linearGradient(listOf(core.copy(alpha = 0.7f), core, Color(0xFF8E1919)))))
        }
    }
}

@Composable
internal fun Vlog3DAudioBar(level: Float) {
    LinearProgressIndicator(
        progress = { level }, modifier = Modifier.size(width = 98.dp, height = 9.dp).vlogGlass()
            .semantics { contentDescription = "Уровень микрофона" },
        color = CameraRecordAccent, trackColor = Color(0x991C1F26)
    )
}
