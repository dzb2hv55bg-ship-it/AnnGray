package ru.momento.app.ui.designsystem

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Switch
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF005BC4), onPrimary = Color.White,
    primaryContainer = Color(0xFFEAF3FF), onPrimaryContainer = Color(0xFF172B4D),
    secondary = Color(0xFF58708F), background = Color(0xFFF1F5FE),
    surface = Color.White, surfaceContainerLow = Color(0xFFFAFCFF),
    surfaceContainer = Color(0xFFE9F0FC), surfaceContainerHigh = Color(0xFFDEE8F8),
    outlineVariant = Color(0xFFD5E1F4), onSurface = Color(0xFF172B4D),
    onSurfaceVariant = Color(0xFF65758B), outline = Color(0xFFDCE4EF)
)
internal val DarkColors = darkColorScheme(
    primary = Color(0xFF9FC6FF), onPrimary = Color(0xFF00325B),
    primaryContainer = Color(0xFF164A80), onPrimaryContainer = Color(0xFFD5E6FF),
    secondary = Color(0xFFB6C8E4), background = Graphite,
    surface = GraphiteLight, surfaceContainerLow = Color(0xFF191D27),
    surfaceContainer = Color(0xFF222733), surfaceContainerHigh = Color(0xFF2C3444),
    outlineVariant = Color(0xFF314764), onSurface = Color(0xFFE8EFFB),
    onSurfaceVariant = Color(0xFFB8C5D9), outline = Color(0xFF52647E)
)

private val MomentoShapes = Shapes(
    extraSmall = RoundedCornerShape(12.dp), small = RoundedCornerShape(18.dp),
    medium = RoundedCornerShape(24.dp), large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

private class ThemeChoice(val dark: Boolean, val update: (Boolean) -> Unit)
private val LocalThemeChoice = staticCompositionLocalOf<ThemeChoice?> { null }

@Composable
fun MomentoTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val prefs = remember(context) { context.getSharedPreferences("momento_display", 0) }
    var dark by remember(prefs) { mutableStateOf(prefs.getBoolean("dark_theme", true)) }
    val choice = ThemeChoice(dark) { selected ->
        dark = selected
        prefs.edit().putBoolean("dark_theme", selected).apply()
    }
    CompositionLocalProvider(LocalThemeChoice provides choice) {
        MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, shapes = MomentoShapes) {
            val backdrop = if (dark) {
                Brush.radialGradient(listOf(GraphiteLight, Graphite), center = Offset(0f, 0f))
            } else {
                Brush.verticalGradient(listOf(LightColors.primaryContainer, LightColors.background))
            }
            Box(Modifier.fillMaxSize().background(backdrop)) { content() }
        }
    }
}

@Composable
internal fun VlogThemeSetting() {
    val choice = LocalThemeChoice.current ?: return
    Vlog3DGlassCard(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("Тёмная тема", modifier = Modifier.weight(1f))
            Switch(checked = choice.dark, onCheckedChange = choice.update,
                modifier = Modifier.semantics { contentDescription = "Тёмная тема" })
        }
    }
}
