package ru.momento.app.ui.designsystem

import androidx.compose.ui.graphics.Color

internal val Graphite = Color(0xFF0A0B0E)
internal val GraphiteLight = Color(0xFF161922)
internal val CameraBackground = Color(0xFF0B0C0E)
internal val GlassSurface = Color(0xA61C1F26)
internal val RimLight = Color(0x38FFFFFF)
internal val CameraRecordAccent = Color(0xFFFF3B30)
