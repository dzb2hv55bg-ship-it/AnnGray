# GitHub-референсы для дизайна MOMENTO

Проверено 114 уникальных публичных страниц репозиториев. Каталог включает источники по реализации, визуальному стилю и проверке интерфейсов. Доступность страницы не означает, что проект поддерживается или что его код и ассеты можно использовать на одинаковых условиях.

## Что применяем в MOMENTO

| Источник | Решение |
| --- | --- |
| [Jetpack Camera App](https://github.com/google/jetpack-camera-app) | Видоискатель занимает основную область. Запись и смена камеры доступны снизу. |
| [Compose Samples](https://github.com/android/compose-samples) | Семантика действий, Material-компоненты и анимация состояния кнопки. |
| [Now in Android](https://github.com/android/nowinandroid) | Семантические цветовые роли и адаптация интерфейса под размер окна. |
| [Material Color Utilities](https://github.com/material-foundation/material-color-utilities) | Раздельные роли поверхностей, текста и акцентов. Коралловый зарезервирован для записи. |
| [Material Design Icons](https://github.com/google/material-design-icons) | Узнаваемый силуэт видеокамеры в лаунчере и одноцветная версия для Android. |
| [Filament](https://github.com/google/filament) | Референс для освещения и материалов 3D-иконок. Для управления камерой предпочтительны лёгкие статические ресурсы. |
| [Paparazzi](https://github.com/cashapp/paparazzi) | Ориентир для визуальной регрессии по размерам окна и темам. |

Полупрозрачные плашки над камерой должны сохранять контраст поверх светлого и тёмного кадра. Неоморфизм и 3D уместны в иллюстрациях и иконке приложения. Состояния интерактивных элементов читаются по форме и подписи.

Пауза и удаление последнего фрагмента требуют отдельной модели дублей с проверкой длительности итогового файла. Для микрофона нужны разрешение и явное управление записью звука. FPS, разрешение и стабилизацию следует предлагать только после проверки возможностей текущей камеры.

## Android, Compose и адаптивность (21)

- [android/compose-samples](https://github.com/android/compose-samples)
- [android/nowinandroid](https://github.com/android/nowinandroid)
- [android/architecture-samples](https://github.com/android/architecture-samples)
- [android/platform-samples](https://github.com/android/platform-samples)
- [android/sunflower](https://github.com/android/sunflower)
- [android/user-interface-samples](https://github.com/android/user-interface-samples)
- [android/codelab-android-compose](https://github.com/android/codelab-android-compose)
- [android/wear-os-samples](https://github.com/android/wear-os-samples)
- [android/tv-samples](https://github.com/android/tv-samples)
- [android/health-samples](https://github.com/android/health-samples)
- [android/graphics-samples](https://github.com/android/graphics-samples)
- [androidx/androidx](https://github.com/androidx/androidx)
- [JetBrains/compose-multiplatform](https://github.com/JetBrains/compose-multiplatform)
- [JetBrains/compose-multiplatform-core](https://github.com/JetBrains/compose-multiplatform-core)
- [JetBrains/compose-multiplatform-template](https://github.com/JetBrains/compose-multiplatform-template)
- [JetBrains/compose-multiplatform-ios-android-template](https://github.com/JetBrains/compose-multiplatform-ios-android-template)
- [chrisbanes/tivi](https://github.com/chrisbanes/tivi)
- [chrisbanes/cheesesquare](https://github.com/chrisbanes/cheesesquare)
- [skydoves/Pokedex](https://github.com/skydoves/Pokedex)
- [skydoves/DisneyCompose](https://github.com/skydoves/DisneyCompose)
- [patrykandpatrick/vico](https://github.com/patrykandpatrick/vico)

## Камера, видео и редактирование (15)

- [google/jetpack-camera-app](https://github.com/google/jetpack-camera-app)
- [android/camera-samples](https://github.com/android/camera-samples)
- [androidx/media](https://github.com/androidx/media)
- [android/media-samples](https://github.com/android/media-samples)
- [google/grafika](https://github.com/google/grafika)
- [natario1/CameraView](https://github.com/natario1/CameraView)
- [CameraKit/camerakit-android](https://github.com/CameraKit/camerakit-android)
- [RedApparat/Fotoapparat](https://github.com/RedApparat/Fotoapparat)
- [googlearchive/android-Camera2Basic](https://github.com/googlearchive/android-Camera2Basic)
- [arthenica/ffmpeg-kit](https://github.com/arthenica/ffmpeg-kit)
- [MasayukiSuda/Mp4Composer-android](https://github.com/MasayukiSuda/Mp4Composer-android)
- [MasayukiSuda/GPUVideo-android](https://github.com/MasayukiSuda/GPUVideo-android)
- [MasayukiSuda/ExoPlayerFilter](https://github.com/MasayukiSuda/ExoPlayerFilter)
- [wasabeef/android-gpuimage](https://github.com/wasabeef/android-gpuimage)
- [google-ai-edge/mediapipe](https://github.com/google-ai-edge/mediapipe)

## UX, навигация и доступность (16)

- [android/testing-samples](https://github.com/android/testing-samples)
- [android/android-test](https://github.com/android/android-test)
- [google/Accessibility-Test-Framework-for-Android](https://github.com/google/Accessibility-Test-Framework-for-Android)
- [mobile-dev-inc/Maestro](https://github.com/mobile-dev-inc/Maestro)
- [appium/appium](https://github.com/appium/appium)
- [appium/appium-uiautomator2-driver](https://github.com/appium/appium-uiautomator2-driver)
- [DequeLabs/axe-core](https://github.com/DequeLabs/axe-core)
- [w3c/wcag](https://github.com/w3c/wcag)
- [WICG/aom](https://github.com/WICG/aom)
- [google/Talkback](https://github.com/google/Talkback)
- [androidx/constraintlayout](https://github.com/androidx/constraintlayout)
- [adrielcafe/voyager](https://github.com/adrielcafe/voyager)
- [raamcosta/compose-destinations](https://github.com/raamcosta/compose-destinations)
- [arkivanov/Decompose](https://github.com/arkivanov/Decompose)
- [slackhq/circuit](https://github.com/slackhq/circuit)
- [airbnb/Showkase](https://github.com/airbnb/Showkase)

## UI, минимализм, токены и тёмные темы (30)

- [material-components/material-components-android](https://github.com/material-components/material-components-android)
- [material-components/material-web](https://github.com/material-components/material-web)
- [material-components/material-components-web](https://github.com/material-components/material-components-web)
- [material-foundation/material-color-utilities](https://github.com/material-foundation/material-color-utilities)
- [google/material-design-icons](https://github.com/google/material-design-icons)
- [googlefonts/roboto-2](https://github.com/googlefonts/roboto-2)
- [notofonts/noto-fonts](https://github.com/notofonts/noto-fonts)
- [google/fonts](https://github.com/google/fonts)
- [microsoft/fluentui-android](https://github.com/microsoft/fluentui-android)
- [microsoft/fluentui](https://github.com/microsoft/fluentui)
- [microsoft/fluentui-system-icons](https://github.com/microsoft/fluentui-system-icons)
- [carbon-design-system/carbon](https://github.com/carbon-design-system/carbon)
- [USWDS/uswds](https://github.com/USWDS/uswds)
- [primer/primitives](https://github.com/primer/primitives)
- [primer/css](https://github.com/primer/css)
- [primer/design](https://github.com/primer/design)
- [Shopify/polaris-react-archive](https://github.com/Shopify/polaris-react-archive)
- [design-tokens/community-group](https://github.com/design-tokens/community-group)
- [tokens-studio/figma-plugin](https://github.com/tokens-studio/figma-plugin)
- [style-dictionary/style-dictionary](https://github.com/style-dictionary/style-dictionary)
- [penpot/penpot](https://github.com/penpot/penpot)
- [storybookjs/storybook](https://github.com/storybookjs/storybook)
- [radix-ui/primitives](https://github.com/radix-ui/primitives)
- [shadcn-ui/ui](https://github.com/shadcn-ui/ui)
- [tailwindlabs/headlessui](https://github.com/tailwindlabs/headlessui)
- [tailwindlabs/tailwindcss](https://github.com/tailwindlabs/tailwindcss)
- [adobe/react-spectrum](https://github.com/adobe/react-spectrum)
- [adobe/spectrum-css](https://github.com/adobe/spectrum-css)
- [figma/plugin-samples](https://github.com/figma/plugin-samples)
- [figma/rest-api-spec](https://github.com/figma/rest-api-spec)

## Motion, обратная связь и визуальные тесты (14)

- [airbnb/lottie-android](https://github.com/airbnb/lottie-android)
- [airbnb/lottie-web](https://github.com/airbnb/lottie-web)
- [rive-app/rive-android](https://github.com/rive-app/rive-android)
- [rive-app/rive-ios](https://github.com/rive-app/rive-ios)
- [alexjlockwood/ShapeShifter](https://github.com/alexjlockwood/ShapeShifter)
- [motiondivision/motion](https://github.com/motiondivision/motion)
- [google/flexbox-layout](https://github.com/google/flexbox-layout)
- [cashapp/paparazzi](https://github.com/cashapp/paparazzi)
- [takahirom/roborazzi](https://github.com/takahirom/roborazzi)
- [meta/screenshot-tests-for-android](https://github.com/meta/screenshot-tests-for-android)
- [robolectric/robolectric](https://github.com/robolectric/robolectric)
- [ReactiveCircus/android-emulator-runner](https://github.com/ReactiveCircus/android-emulator-runner)
- [dropbox/differ](https://github.com/dropbox/differ)
- [kdrag0n/colorkt](https://github.com/kdrag0n/colorkt)

## Иконки, стекло, иллюстрация и 3D (18)

- [lucide-icons/lucide](https://github.com/lucide-icons/lucide)
- [phosphor-icons/core](https://github.com/phosphor-icons/core)
- [tabler/tabler-icons](https://github.com/tabler/tabler-icons)
- [feathericons/feather](https://github.com/feathericons/feather)
- [twbs/icons](https://github.com/twbs/icons)
- [FortAwesome/Font-Awesome](https://github.com/FortAwesome/Font-Awesome)
- [Iconify/iconify](https://github.com/Iconify/iconify)
- [material-icons/material-icons](https://github.com/material-icons/material-icons)
- [pictogrammers/pictogrammers.github.io](https://github.com/pictogrammers/pictogrammers.github.io)
- [googlefonts/noto-emoji](https://github.com/googlefonts/noto-emoji)
- [twitter/twemoji](https://github.com/twitter/twemoji)
- [google/filament](https://github.com/google/filament)
- [mrdoob/three.js](https://github.com/mrdoob/three.js)
- [BabylonJS/Babylon.js](https://github.com/BabylonJS/Babylon.js)
- [blender/blender](https://github.com/blender/blender)
- [KhronosGroup/glTF-Sample-Assets](https://github.com/KhronosGroup/glTF-Sample-Assets)
- [google/model-viewer](https://github.com/google/model-viewer)
- [cesiumlab/cesiumlab](https://github.com/cesiumlab/cesiumlab)

## Материалы и зависимости MOMENTO

Kotlin, Jetpack Compose, Material 3, CameraX и Media3 составляют текущий стек. Файлы `ui/designsystem/Color.kt`, `Theme.kt`, `Modifiers3D.kt` и `Components3D.kt` задают цветовые роли, выбор темы, освещение и интерактивные компоненты. Общие компоненты используются в камере, архиве, профиле, карточках комнат и форме входа. Для смешанных экранов оставлены штатные поля, переключатели и диалоги Material 3.

Микроанимации используют Compose Animation, а объём рисуется градиентами и тенью Compose. Haze подходит для слоёв, которые отрисовывает сам Compose. Камера использует AndroidView с CameraX PreviewView, поэтому стеклянные элементы над видео используют полупрозрачную поверхность с контрастной нижней гранью. Haze, Lottie и BlurView на этом этапе не добавлены в Gradle. [Haze](https://github.com/chrisbanes/haze) · [Lottie Android](https://github.com/airbnb/lottie-android) · [BlurView](https://github.com/Dimezis/BlurView)
