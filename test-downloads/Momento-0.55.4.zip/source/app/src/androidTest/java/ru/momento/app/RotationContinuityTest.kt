package ru.momento.app

import android.app.UiAutomation
import android.content.res.Configuration
import android.os.SystemClock
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class RotationContinuityTest {
    @get:Rule val activityRule = ActivityScenarioRule(MainActivity::class.java)

    @Test fun displayRotationKeepsTheActivityOwningTheCameraSession() {
        val automation = InstrumentationRegistry.getInstrumentation().uiAutomation
        val scenario = activityRule.scenario
        lateinit var initial: MainActivity
        var initialOrientation = Configuration.ORIENTATION_UNDEFINED
        scenario.onActivity {
            initial = it
            initialOrientation = it.resources.configuration.orientation
        }
        try {
            val rotation = if (initialOrientation == Configuration.ORIENTATION_PORTRAIT) {
                UiAutomation.ROTATION_FREEZE_90
            } else UiAutomation.ROTATION_FREEZE_0
            assertTrue(automation.setRotation(rotation))
            val deadline = SystemClock.elapsedRealtime() + 5_000L
            var actualOrientation = initialOrientation
            do {
                scenario.onActivity {
                    actualOrientation = it.resources.configuration.orientation
                    if (actualOrientation != initialOrientation) assertSame(initial, it)
                }
                if (actualOrientation == initialOrientation) SystemClock.sleep(100)
            } while (actualOrientation == initialOrientation && SystemClock.elapsedRealtime() < deadline)
            assertNotEquals("Display did not rotate", initialOrientation, actualOrientation)
        } finally {
            automation.setRotation(UiAutomation.ROTATION_UNFREEZE)
        }
    }
}
