package ru.momento.app.ui.designsystem

import androidx.compose.ui.graphics.Color

internal val Graphite = Color(0xFF0C1220)
internal val GraphiteLight = Color(0xFF101E36)
internal val CameraBackground = Color(0xFF172A47)
internal val GlassSurface = Color(0xCC1B3357)
internal val RimLight = Color(0x38FFFFFF)
internal val CameraRecordAccent = Color(0xFFFF3B30)

internal val CameraScrim = Color(0xD9162E51)
internal val BrandBlue = Color(0xFF176BFF)
