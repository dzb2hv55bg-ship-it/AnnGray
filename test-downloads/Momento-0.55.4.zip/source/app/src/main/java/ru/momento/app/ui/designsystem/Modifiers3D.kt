package ru.momento.app.ui.designsystem

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

internal fun Modifier.vlogGlass(
    shape: Shape = CircleShape,
    depth: Dp = 8.dp,
    material: Color = GlassSurface
): Modifier = shadow(depth, shape)
    .clip(shape)
    .background(material)
    .background(Brush.linearGradient(
        listOf(RimLight, Color.Transparent, Color(0xFF142C54).copy(alpha = if (material.luminance() > 0.5f) 0.06f else 0.18f)),
        start = Offset.Zero, end = Offset.Infinite
    ))
    .border(1.dp, RimLight, shape)
