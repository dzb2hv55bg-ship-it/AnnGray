package ru.momento.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.annotation.DrawableRes
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.res.painterResource
import ru.momento.app.R
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.PersonOutline
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ru.momento.app.ui.designsystem.Vlog3DButton
import ru.momento.app.ui.designsystem.Vlog3DGlassCard
import ru.momento.app.ui.designsystem.vlogGlass

/** Shared, dependency-free MOMENTO visual language. */
@Composable
internal fun MomentoNavigationBar(selectedIndex: Int, onSelect: (Int) -> Unit) {
    val labels = listOf("Камера", "Комнаты", "Подписки", "Профиль")
    val icons = listOf(Icons.Default.Videocam, Icons.Default.VideoLibrary,
        Icons.Default.FavoriteBorder, Icons.Default.PersonOutline)
    NavigationBar(
        modifier = Modifier.padding(horizontal = 8.dp).vlogGlass(
            RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
            material = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        containerColor = Color.Transparent, tonalElevation = 0.dp
    ) {
        labels.forEachIndexed { index, label ->
            NavigationBarItem(
                selected = selectedIndex == index,
                onClick = { onSelect(index) },
                icon = { Icon(icons[index], contentDescription = null) },
                label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                alwaysShowLabel = true,
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = MaterialTheme.colorScheme.primary
                )
            )
        }
    }
}

@Composable
internal fun MomentoSectionTitle(title: String, subtitle: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface)
        if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
internal fun MomentoInfoCard(title: String, message: String, action: String? = null,
                            onAction: (() -> Unit)? = null) {
    Vlog3DGlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(message, style = MaterialTheme.typography.bodyMedium)
            if (action != null && onAction != null) {
                TextButton(onClick = onAction) { Text(action) }
            }
        }
    }
}


/** Single source of spacing, corner radii and motion-independent UI primitives. */
internal object MomentoTokens {
    val screenPadding = 20.dp
    val cardRadius = 24.dp
    val controlRadius = 18.dp
    val sectionGap = 16.dp
    val contentGap = 8.dp
}

@Composable
internal fun MomentoPrimaryAction(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true
) {
    Vlog3DButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.fillMaxWidth().heightIn(min = 52.dp)
    ) { Text(text, style = MaterialTheme.typography.labelLarge) }
}

@Composable
internal fun MomentoStatePanel(
    title: String, detail: String, actionLabel: String? = null, onAction: (() -> Unit)? = null,
    isError: Boolean = false,
    @DrawableRes illustration: Int? = null
) {
    val palette = MaterialTheme.colorScheme
    Card(
        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(MomentoTokens.cardRadius),
        border = BorderStroke(1.dp, if (isError) palette.error.copy(alpha = 0.35f) else palette.outlineVariant),
        colors = CardDefaults.cardColors(containerColor = if (isError) palette.errorContainer else palette.surfaceContainerLow)
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val art = illustration ?: if (isError) R.drawable.momento_art_error else null
            if (art != null) MomentoIllustration(art) else Icon(Icons.Default.Info, null, tint = palette.primary)
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                color = if (isError) palette.onErrorContainer else palette.onSurface)
            Text(detail, style = MaterialTheme.typography.bodyMedium,
                color = if (isError) palette.onErrorContainer else palette.onSurfaceVariant)
            if (actionLabel != null && onAction != null) {
                TextButton(onClick = onAction) { Text(actionLabel) }
            }
        }
    }
}

@Composable
internal fun MomentoRoomTile(
    title: String, description: String, metadata: String, onClick: () -> Unit,
    footer: String? = null,
    icon: ImageVector = Icons.Default.VideoLibrary
) {
    Card(
        onClick = onClick, modifier = Modifier.fillMaxWidth().vlogGlass(MaterialTheme.shapes.medium,
            material = MaterialTheme.colorScheme.surfaceContainer),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(54.dp).background(
                Brush.verticalGradient(listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.surfaceContainerHigh)),
                RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(25.dp))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (description.isNotBlank()) Text(description, style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (metadata.isNotBlank()) Text(metadata, style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary)
                if (footer != null) Text(footer, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
internal fun MomentoProfileHeader(title: String, description: String) {
    val palette = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxWidth().vlogGlass(MaterialTheme.shapes.extraLarge,
            material = palette.primaryContainer).padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Surface(color = palette.surface, shape = CircleShape) {
            Icon(Icons.Default.PersonOutline, null, Modifier.padding(12.dp).size(24.dp), tint = palette.primary)
        }
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(description, style = MaterialTheme.typography.bodyMedium, color = palette.onSurfaceVariant)
    }
}

/** Account-wide reminder policy; no per-room hour/count controls are exposed. */
@Composable
internal fun MomentoReminderPolicyCard(enabled: Boolean, onToggle: (Boolean) -> Unit, permissionGranted: Boolean) {
    Vlog3DGlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(MomentoTokens.screenPadding), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    MomentoIllustration(R.drawable.momento_art_reminders)
                    Text("Ежедневные напоминания", style = MaterialTheme.typography.titleMedium)
                    Text("5 случайных напоминаний в день, 09:00–21:00. Между ними не менее 45 минут.",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = enabled, onCheckedChange = onToggle, modifier = Modifier.semantics {
                    contentDescription = "Включить или отключить напоминания"
                })
            }
            if (!permissionGranted) Text("Для доставки уведомлений разреши их в настройках Android.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
    }
}

@Composable
internal fun MomentoScreenHeading(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(bottom = MomentoTokens.sectionGap),
        verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}


@Composable
internal fun MomentoBrand() {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(painterResource(R.drawable.momento_play_mark), null, Modifier.size(26.dp), tint = Color.Unspecified)
        Text("MOMENTO", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    }
}


@Composable
internal fun MomentoIllustration(@DrawableRes resource: Int, modifier: Modifier = Modifier) {
    Image(painterResource(resource), null, modifier.size(width = 120.dp, height = 80.dp))
}

@Composable
internal fun MomentoFilmCard(onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Жизнь в секундах", style = MaterialTheme.typography.titleMedium)
                Text("Посмотри, из каких моментов состоит твоя жизнь.",
                    style = MaterialTheme.typography.bodyMedium)
            }
            MomentoIllustration(R.drawable.momento_art_film, Modifier.padding(start = 4.dp).widthIn(max = 96.dp))
        }
    }
}
