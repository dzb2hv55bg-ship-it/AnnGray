package ru.momento.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import ru.momento.app.R

@Composable
internal fun MomentoIntroduction(onFinish: () -> Unit) {
    var page by rememberSaveable { mutableIntStateOf(0) }
    val titles = listOf(R.string.intro_record, R.string.intro_room, R.string.intro_film)
    val descriptions = listOf(R.string.intro_record_body, R.string.intro_room_body, R.string.intro_film_body)
    val artwork = listOf(R.drawable.momento_art_moments, R.drawable.momento_art_event, R.drawable.momento_art_film)
    Column(
        Modifier.fillMaxSize().safeDrawingPadding().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        MomentoBrand()
        MomentoIllustration(artwork[page], Modifier.padding(top = 32.dp))
        Text(stringResource(titles[page]), style = MaterialTheme.typography.headlineLarge)
        Text(stringResource(descriptions[page]), style = MaterialTheme.typography.bodyLarge)
        Text(stringResource(R.string.intro_progress, page + 1, titles.size), style = MaterialTheme.typography.bodyMedium)
        MomentoPrimaryAction(stringResource(if (page == titles.lastIndex) R.string.intro_start else R.string.intro_next),
            onClick = { if (page == titles.lastIndex) onFinish() else page++ })
        TextButton(onClick = onFinish) { Text(stringResource(R.string.intro_skip)) }
    }
}
