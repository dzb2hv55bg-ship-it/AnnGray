package ru.momento.app.ui

import android.Manifest
import android.view.HapticFeedbackConstants
import androidx.activity.compose.BackHandler
import androidx.camera.core.Camera
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.TextButton
import androidx.compose.ui.geometry.Offset
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import androidx.compose.foundation.Image
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.os.StatFs
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.DynamicRange
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.selected
import androidx.lifecycle.Lifecycle
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import android.content.res.Configuration
import android.view.Surface
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.ListItem
import androidx.compose.material.icons.filled.Check
import ru.momento.app.ui.designsystem.CameraScrim
import androidx.compose.ui.res.painterResource
import ru.momento.app.R
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import ru.momento.app.ui.designsystem.CameraBackground
import ru.momento.app.ui.designsystem.Vlog3DAudioBar
import ru.momento.app.ui.designsystem.Vlog3DIconButton
import ru.momento.app.ui.designsystem.Vlog3DShutterButton
import ru.momento.app.ui.designsystem.vlogGlass
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CameraScreen(
    roomNames: List<Pair<String, String>> = emptyList(),
    verifiedOwnerId: String,
    selectedRoomId: String? = null,
    onRoomSelected: (String) -> Unit = {},
    latestMoment: File? = null,
    onArchive: (() -> Unit)? = null,
    onCreateRoom: (() -> Unit)? = null,
    bottomNavigation: (@Composable (Boolean) -> Unit)? = null,
    onSaved: (File, Long) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val lifecycleOwner = LocalLifecycleOwner.current
    val mainExecutor = remember(context) { ContextCompat.getMainExecutor(context) }
    var hasCameraPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    var permissionDenied by remember { mutableStateOf(false) }
    var frontFacing by rememberSaveable { mutableStateOf(false) }
    var canSwitch by remember { mutableStateOf(false) }
    val viewfinder = remember(context) {
        PreviewView(context).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var zoomRatio by remember { mutableStateOf(1f) }
    var torchEnabled by remember { mutableStateOf(false) }
    var captureSettingsOpen by remember { mutableStateOf(false) }
    var preferUhd by rememberSaveable { mutableStateOf(false) }
    var preferStabilization by rememberSaveable { mutableStateOf(false) }
    var uhdAvailable by remember { mutableStateOf(false) }
    var stabilizationAvailable by remember { mutableStateOf(false) }
    var gridEnabled by rememberSaveable { mutableStateOf(false) }
    var videoCapture by remember { mutableStateOf<VideoCapture<Recorder>?>(null) }
    var recording by remember { mutableStateOf<Recording?>(null) }
    var isRecording by remember { mutableStateOf(false) }
    var isBusy by remember { mutableStateOf(false) }
    var recordedMillis by remember { mutableStateOf(0L) }
    var paused by remember { mutableStateOf(false) }
    var pausePending by remember { mutableStateOf(false) }
    var audioEnabled by remember { mutableStateOf(false) }
    var audioLevel by remember { mutableStateOf(0f) }
    var soundUnavailable by remember { mutableStateOf(false) }
    var activeOutput by remember { mutableStateOf<File?>(null) }
    val cancelledPaths = remember { mutableSetOf<String>() }
    val secondsElapsed = (recordedMillis / 1000L).toInt().coerceAtMost(5)
    var errorMessage by remember { mutableStateOf<String?>(null) }

    BackHandler { if (!isBusy) onClose() }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasCameraPermission = granted
        permissionDenied = !granted
    }

    val microphonePermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        audioEnabled = granted
        soundUnavailable = !granted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    DisposableEffect(lifecycleOwner, viewfinder, hasCameraPermission, frontFacing, preferUhd, preferStabilization) {
        var disposed = false
        var provider: ProcessCameraProvider? = null
        var boundPreview: Preview? = null
        var boundCapture: VideoCapture<Recorder>? = null
        videoCapture = null
        camera = null
        zoomRatio = 1f
        torchEnabled = false
        if (hasCameraPermission) {
            val future = ProcessCameraProvider.getInstance(context)
            future.addListener({
                if (!disposed && lifecycleOwner.lifecycle.currentState != Lifecycle.State.DESTROYED) {
                    try {
                        val ready = future.get()
                        provider = ready
                        val hasFront = ready.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)
                        val hasBack = ready.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA)
                        canSwitch = hasFront && hasBack
                        check(hasFront || hasBack) { "На устройстве нет доступной камеры" }
                        val useFront = hasFront && (frontFacing || !hasBack)
                        val selector = if (useFront) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                        val preview = Preview.Builder().build().also { it.surfaceProvider = viewfinder.surfaceProvider }
                        val capabilities = Recorder.getVideoCapabilities(ready.getCameraInfo(selector))
                        uhdAvailable = Quality.UHD in capabilities.getSupportedQualities(DynamicRange.SDR)
                        stabilizationAvailable = capabilities.isStabilizationSupported
                        val quality = if (preferUhd && uhdAvailable) Quality.UHD else Quality.HD
                        val recorder = Recorder.Builder()
                            .setQualitySelector(QualitySelector.from(quality, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)))
                            .build()
                        val capture = VideoCapture.Builder(recorder)
                            .setVideoStabilizationEnabled(preferStabilization && stabilizationAvailable)
                            .build()
                        boundPreview = preview
                        boundCapture = capture
                        camera = ready.bindToLifecycle(lifecycleOwner, selector, preview, capture)
                        videoCapture = capture
                        errorMessage = null
                    } catch (_: Exception) {
                        errorMessage = "Не удалось открыть камеру. Попробуй другую камеру или открой экран заново."
                    }
                }
            }, mainExecutor)
        }
        onDispose {
            disposed = true
            activeOutput?.let { cancelledPaths.add(it.absolutePath) }
            recording?.stop()
            val preview = boundPreview
            val capture = boundCapture
            if (preview != null && capture != null) provider?.unbind(preview, capture)
        }
    }

    fun startRecording() {
        if (isBusy) return
        val capture = videoCapture ?: return
        // Freeze the output orientation for this clip. A display rotation must not rebind CameraX.
        capture.targetRotation = viewfinder.display?.rotation ?: Surface.ROTATION_0
        val directory = File(context.filesDir, "moments_${ru.momento.app.data.LocalMomentDatabase.databaseNameForAccount(verifiedOwnerId).removeSuffix(".db")}").apply { mkdirs() }
        if (!directory.isDirectory || StatFs(directory.absolutePath).availableBytes < 30L * 1024 * 1024) {
            errorMessage = "Недостаточно места для записи момента."
            return
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val output = File(directory, "moment_$stamp.mp4")
        val options = FileOutputOptions.Builder(output).setDurationLimitMillis(4_800L).build()
        errorMessage = null
        recordedMillis = 0L
        paused = false
        pausePending = false
        audioLevel = 0f
        soundUnavailable = false
        isBusy = true
        activeOutput = output
        try {
            val pending = capture.output.prepareRecording(context, options)
            if (audioEnabled) {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    audioEnabled = false
                    soundUnavailable = true
                } else {
                    pending.withAudioEnabled()
                }
            }
            recording = pending.start(mainExecutor) { event ->
                recordedMillis = event.recordingStats.recordedDurationNanos / 1_000_000
                if (audioEnabled && event is VideoRecordEvent.Status) {
                    val audio = event.recordingStats.audioStats
                    audioLevel = audio.audioAmplitude.toFloat().coerceIn(0f, 1f)
                    soundUnavailable = audio.hasError() || !audio.hasAudio()
                }
                when (event) {
                    is VideoRecordEvent.Start -> {
                        isRecording = true
                        viewfinder.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                    }
                    is VideoRecordEvent.Pause -> {
                        paused = true
                        pausePending = false
                        audioLevel = 0f
                    }
                    is VideoRecordEvent.Resume -> {
                        paused = false
                        pausePending = false
                    }
                    is VideoRecordEvent.Finalize -> {
                        if (isRecording) viewfinder.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                        isRecording = false
                        paused = false
                        pausePending = false
                        audioLevel = 0f
                        recording = null
                        isBusy = false
                        activeOutput = null
                        if (cancelledPaths.remove(output.absolutePath)) {
                            output.delete()
                            errorMessage = "Запись отменена"
                        } else if ((!event.hasError() || event.error == VideoRecordEvent.Finalize.ERROR_DURATION_LIMIT_REACHED) && output.exists() && output.length() > 0L) {
                            val retriever = MediaMetadataRetriever()
                            val duration = try {
                                retriever.setDataSource(output.absolutePath)
                                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                            } catch (_: Exception) {
                                null
                            } finally {
                                try { retriever.release() } catch (_: Exception) { }
                            }
                            if (duration != null && duration in 2_000L..5_000L) {
                                // Keep the only successful file until the caller has indexed it.
                                try { onSaved(output, duration) }
                                catch (e: Exception) { errorMessage = "Момент сохранён на устройстве, но не добавлен в очередь. Файл сохранён: ${output.name}" }
                            } else {
                                output.delete()
                                errorMessage = "Видео не прошло проверку длительности. Попробуй записать ещё раз."
                            }
                        } else {
                            output.delete()
                            errorMessage = "Не удалось сохранить видео. Попробуй ещё раз."
                        }
                    }
                }
            }
        } catch (e: Exception) {
            isBusy = false
            isRecording = false
            recording = null
            activeOutput = null
            output.delete()
            errorMessage = "Не удалось начать запись: ${e.localizedMessage ?: "ошибка камеры"}"
        }
    }

    fun cancelRecording() {
        activeOutput?.let { cancelledPaths.add(it.absolutePath) }
        recording?.stop()
    }

    val thumbnail by produceState<ImageBitmap?>(null, latestMoment) {
        value = null
        if (latestMoment != null) {
            value = withContext(Dispatchers.IO) {
                runCatching {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(latestMoment.absolutePath)
                        if (android.os.Build.VERSION.SDK_INT >= 27) {
                            retriever.getScaledFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 120, 120)?.asImageBitmap()
                        } else null
                    } finally {
                        retriever.release()
                    }
                }.getOrNull()
            }
        }
    }
    var roomPickerOpen by remember { mutableStateOf(false) }
    val destination = roomNames.firstOrNull { it.first == selectedRoomId }?.second ?: "Личный момент"
    if (roomPickerOpen) {
        ModalBottomSheet(onDismissRequest = { roomPickerOpen = false }) {
            Text("Выбрать комнату", Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                style = MaterialTheme.typography.titleLarge)
            LazyColumn(Modifier.heightIn(max = if (landscape) 180.dp else 420.dp)) {
                items(roomNames, key = { it.first }) { (id, title) ->
                    ListItem(
                        headlineContent = { Text(title) },
                        modifier = Modifier.clickable {
                            onRoomSelected(id)
                            roomPickerOpen = false
                        }.semantics { selected = id == selectedRoomId },
                        trailingContent = {
                            if (id == selectedRoomId) Icon(Icons.Default.Check, "Выбрана")
                        }
                    )
                }
            }
            if (roomNames.isEmpty()) Text("Пока нет комнат", Modifier.padding(horizontal = 20.dp))
            onCreateRoom?.let { create ->
                MomentoPrimaryAction("Создать комнату", onClick = {
                    roomPickerOpen = false
                    create()
                }, modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp))
            }
        }
    }
    if (captureSettingsOpen) {
        ModalBottomSheet(onDismissRequest = { captureSettingsOpen = false }) {
            Column(Modifier.padding(horizontal = 24.dp).padding(bottom = 24.dp)) {
                Text("Параметры камеры", style = MaterialTheme.typography.titleLarge)
                Text("Доступные режимы зависят от выбранной камеры.")
                TextButton(
                    enabled = uhdAvailable,
                    onClick = { preferUhd = !preferUhd; captureSettingsOpen = false }
                ) { Text(if (preferUhd && uhdAvailable) "4K · перейти на HD" else if (uhdAvailable) "HD · перейти на 4K" else "4K недоступно") }
                TextButton(
                    enabled = stabilizationAvailable,
                    onClick = { preferStabilization = !preferStabilization; captureSettingsOpen = false }
                ) { Text(when {
                    !stabilizationAvailable -> "Стабилизация недоступна"
                    preferStabilization -> "Выключить стабилизацию"
                    else -> "Включить стабилизацию"
                }) }
            }
        }
    }
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).safeDrawingPadding().padding(horizontal = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose, enabled = !isBusy) { Icon(Icons.Default.Close, "Закрыть камеру") }
            Column(Modifier.weight(1f)) {
                if (!landscape) MomentoBrand()
                val lens = if (frontFacing) "Фронтальная" else "Задняя"
                Text(if (canSwitch) "$destination · $lens" else destination,
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            }
            if (roomNames.isNotEmpty() || onCreateRoom != null) TextButton(onClick = { roomPickerOpen = true }, enabled = !isBusy) {
                Text("Выбрать комнату")
            }
            TextButton(onClick = { captureSettingsOpen = true }, enabled = !isBusy && camera != null) {
                Icon(painterResource(R.drawable.vlog_settings), "Параметры камеры", tint = MaterialTheme.colorScheme.primary)
                if (preferUhd && uhdAvailable) Text("4K")
            }
        }
        Box(
            Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(32.dp)).background(CameraBackground)
        ) {
            if (hasCameraPermission) {
                AndroidView(factory = { viewfinder }, modifier = Modifier.fillMaxSize())
            } else {
                Column(
                    Modifier.align(Alignment.Center).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(if (permissionDenied) "Разреши доступ к камере, чтобы записать момент." else "Запрашиваем доступ к камере…",
                        color = Color.White)
                    if (permissionDenied) OutlinedButton(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }) {
                        Text("Запросить доступ", color = Color.White)
                    }
                }
            }
            if (gridEnabled && videoCapture != null) {
                Canvas(Modifier.fillMaxSize()) {
                    for (index in 1..2) {
                        val x = size.width * index / 3
                        val y = size.height * index / 3
                        drawLine(Color.White.copy(alpha = 0.45f), Offset(x, 0f), Offset(x, size.height))
                        drawLine(Color.White.copy(alpha = 0.45f), Offset(0f, y), Offset(size.width, y))
                    }
                }
            }
            if (hasCameraPermission) Column(
                Modifier.align(if (landscape) Alignment.TopStart else Alignment.TopCenter).padding(top = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    Modifier.vlogGlass().padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(enabled = !isBusy, onClick = {
                        if (audioEnabled) {
                            audioEnabled = false
                            soundUnavailable = false
                        } else if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            audioEnabled = true
                            soundUnavailable = false
                        } else {
                            microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }) {
                        Icon(painterResource(R.drawable.vlog_mic), null,
                            modifier = Modifier.padding(end = 4.dp).size(16.dp), tint = Color.Unspecified)
                        Text(if (audioEnabled) "Звук вкл." else "Без звука")
                    }
                    TextButton(onClick = { gridEnabled = !gridEnabled }) {
                        Text(if (gridEnabled) "Сетка вкл." else "Сетка")
                    }
                    camera?.takeIf { it.cameraInfo.hasFlashUnit() }?.let { activeCamera ->
                        TextButton(onClick = {
                            val requested = !torchEnabled
                            val change = activeCamera.cameraControl.enableTorch(requested)
                            change.addListener({
                                if (camera === activeCamera && runCatching { change.get() }.isSuccess) {
                                    torchEnabled = requested
                                }
                            }, mainExecutor)
                        }) { Text(if (torchEnabled) "Фонарь вкл." else "Фонарь") }
                    }
                }
                Text(
                    if (paused) "Пауза  0:0${secondsElapsed} / 0:05"
                    else if (isRecording) "●  REC  0:0${secondsElapsed} / 0:05" else if (isBusy) "Сохраняем момент…" else "2–5 секунд",
                    Modifier.vlogGlass().padding(horizontal = 16.dp, vertical = 8.dp),
                    color = if (isRecording && !paused) Color(0xFFFFA39E) else Color.White
                )
                if (isRecording && audioEnabled && !paused && !soundUnavailable) {
                    Vlog3DAudioBar(audioLevel)
                }
            }
            if (hasCameraPermission) {
                Column(
                    Modifier.align(if (landscape) Alignment.BottomEnd else Alignment.BottomCenter)
                        .fillMaxWidth(if (landscape) 0.55f else 1f)
                        .background(Brush.verticalGradient(listOf(Color.Transparent, CameraScrim)))
                        .padding(top = 12.dp, bottom = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                camera?.let { activeCamera ->
                    val zoom = activeCamera.cameraInfo.zoomState.value
                    val stops = listOf(0.5f to "0,5×", 1f to "1×", 2f to "2×").filter { (ratio, _) ->
                        zoom != null && ratio in zoom.minZoomRatio..zoom.maxZoomRatio
                    }
                    if (stops.size > 1 && (!landscape || !isBusy)) Row(Modifier.vlogGlass().padding(horizontal = 4.dp)) {
                        stops.forEach { (ratio, label) ->
                            TextButton(onClick = {
                                val change = activeCamera.cameraControl.setZoomRatio(ratio)
                                change.addListener({
                                    if (camera === activeCamera && runCatching { change.get() }.isSuccess) {
                                        zoomRatio = ratio
                                        viewfinder.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                                    }
                                }, mainExecutor)
                            }, modifier = Modifier.semantics { selected = ratio == zoomRatio }) {
                                Text(label, color = if (ratio == zoomRatio) Color.White else Color(0xFFB1BDD1))
                            }
                        }
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    if (isBusy) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            IconButton(
                                enabled = isRecording && !pausePending,
                                onClick = {
                                    recording?.let {
                                        pausePending = true
                                        if (paused) it.resume() else it.pause()
                                    }
                                },
                                modifier = Modifier.vlogGlass()
                            ) {
                                Icon(painterResource(if (paused) R.drawable.vlog_resume else R.drawable.vlog_pause),
                                    if (paused) "Продолжить запись" else "Пауза", tint = Color.Unspecified)
                            }
                            IconButton(onClick = ::cancelRecording) {
                                Icon(Icons.Default.Close, "Отменить запись", tint = Color.White)
                            }
                        }
                    } else if (onArchive != null) {
                        Vlog3DIconButton(onArchive, "Открыть личный архив") {
                            val frame = thumbnail
                            if (frame != null) Image(frame, null,
                                modifier = Modifier.size(32.dp).clip(RoundedCornerShape(9.dp)),
                                contentScale = ContentScale.Crop)
                            else Icon(painterResource(R.drawable.vlog_archive), null, tint = Color.Unspecified)
                        }
                    } else Spacer(Modifier.size(48.dp))
                    val readyToStop = isRecording && !pausePending && recordedMillis >= 2_000L
                    Vlog3DShutterButton(
                        busy = isBusy, paused = paused,
                        enabled = readyToStop || (!isBusy && videoCapture != null),
                        progress = (recordedMillis / 5_000f).coerceIn(0f, 1f),
                        onClick = { if (readyToStop) recording?.stop() else if (!isBusy) startRecording() }
                    )
                    if (canSwitch) {
                        Vlog3DIconButton(
                            description = if (frontFacing) "Переключить на заднюю камеру" else "Переключить на фронтальную камеру",
                            onClick = {
                                videoCapture = null
                                errorMessage = null
                                frontFacing = !frontFacing
                            },
                            enabled = !isBusy
                        ) {
                            Icon(painterResource(R.drawable.vlog_lens_switch), null, tint = Color.Unspecified)
                        }
                    } else Spacer(Modifier.size(48.dp))
                }
                }
            }
        }
        if ((!landscape && bottomNavigation == null) || errorMessage != null) Text(
            errorMessage ?: when {
                !hasCameraPermission -> "Камера используется только для записи моментов."
                soundUnavailable -> "Микрофон недоступен. Проверь разрешение на запись звука."
                paused -> "Продолжи запись или сохрани момент, если записано две секунды."
                isRecording && secondsElapsed < 2 -> "Остановить запись можно после двух секунд."
                isRecording -> "Останови сейчас или дождись автоматического завершения."
                videoCapture == null -> "Подключаем камеру…"
                audioEnabled -> "Видео со звуком появится в архиве."
                else -> "Видео появится в архиве. Запись без звука."
            },
            Modifier.padding(bottom = 12.dp),
            color = if (errorMessage == null) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error,
            style = MaterialTheme.typography.bodyMedium
        )
        if (!landscape) bottomNavigation?.invoke(!isBusy)
    }
}
