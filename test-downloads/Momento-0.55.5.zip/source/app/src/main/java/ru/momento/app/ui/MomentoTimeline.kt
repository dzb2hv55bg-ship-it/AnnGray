package ru.momento.app.ui

import android.media.MediaMetadataRetriever
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import ru.momento.app.data.LocalMoment
import java.text.DateFormat
import java.util.Date

@Composable
internal fun MomentoTimeline(moments: List<LocalMoment>, active: Int, onSelect: (Int) -> Unit) {
    val moment = moments.getOrNull(active) ?: return
    val dateFormat = remember { DateFormat.getDateInstance(DateFormat.MEDIUM) }
    val day = dateFormat.format(Date(moment.capturedAtMillis))
    val days = remember(moments, dateFormat) { moments.map { dateFormat.format(Date(it.capturedAtMillis)) } }
    val previous = (active - 1 downTo 0).firstOrNull { days[it] != day }
    val next = (active + 1..moments.lastIndex).firstOrNull { days[it] != day }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically) {
        TextButton(enabled = previous != null, onClick = { previous?.let(onSelect) }) { Text("← День") }
        Text(day, style = MaterialTheme.typography.labelMedium)
        TextButton(enabled = next != null, onClick = { next?.let(onSelect) }) { Text("День →") }
    }
    val positions = remember(days, day) { days.indices.filter { days[it] == day } }
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(positions, key = { moments[it].id }) { index ->
            val item = moments[index]
                val shape = RoundedCornerShape(12.dp)
                Surface(
                    modifier = Modifier.size(72.dp).clip(shape).border(
                        if (index == active) 2.dp else 1.dp,
                        if (index == active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                        shape
                    ).selectable(index == active, role = Role.Button, onClick = { onSelect(index) }),
                    color = MaterialTheme.colorScheme.surfaceContainer
                ) {
                    val frame by produceState<ImageBitmap?>(null, item.localPath) {
                        if (Build.VERSION.SDK_INT < 27) return@produceState
                        value = withContext(Dispatchers.IO) {
                            runCatching {
                                val retriever = MediaMetadataRetriever()
                                try {
                                    retriever.setDataSource(item.localPath)
                                    retriever.getScaledFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 144, 144)?.asImageBitmap()
                                } finally { retriever.release() }
                            }.getOrNull()
                        }
                    }
                    Box(contentAlignment = Alignment.Center) {
                        frame?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                            ?: Icon(Icons.Default.PlayArrow, null)
                        Surface(Modifier.align(Alignment.BottomEnd).padding(4.dp),
                            shape = RoundedCornerShape(5.dp), color = MaterialTheme.colorScheme.surface) {
                            Text("${item.durationMillis / 1000.0} с", Modifier.padding(horizontal = 4.dp),
                                style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
        }
    }
}
