package ru.momento.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import ru.momento.app.R
import ru.momento.app.data.LocalSpace
import ru.momento.app.network.MomentoApiClient
import ru.momento.app.network.RemoteSpace

@Composable
internal fun LiveHomeScreen(
    rooms: List<LocalSpace>,
    accessToken: String,
    api: MomentoApiClient,
    filter: Int,
    onFilter: (Int) -> Unit,
    onCreate: () -> Unit,
    onSpecialRooms: () -> Unit,
    onOpen: (String) -> Unit,
    onOpenPublic: (String) -> Unit
) {
    var subscribed by remember(accessToken) { mutableStateOf<Set<String>>(emptySet()) }
    var changing by remember { mutableStateOf<String?>(null) }
    var actionFailed by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var search by rememberSaveable { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    var entries by remember(accessToken) { mutableStateOf<List<RemoteSpace>>(emptyList()) }
    LaunchedEffect(accessToken, filter) {
        if (filter == 2) {
            try {
                val follows = api.getSubscriptions(accessToken).optJSONArray("rooms")
                subscribed = List(follows?.length() ?: 0) { checkNotNull(follows).getJSONObject(it).getString("id") }.toSet()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                actionFailed = true
            }
        }
    }
    LaunchedEffect(filter, search, refresh, accessToken) {
        if (filter != 2) return@LaunchedEffect
        loading = true
        failed = false
        try {
            delay(250)
            entries = api.discoverSpaces(accessToken, search)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            failed = true
        } finally {
            loading = false
        }
    }
    val local = when (filter) {
        0 -> rooms.toList()
        1 -> rooms.filter { it.visibility == "LINK" }
        else -> emptyList()
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Комнаты", style = MaterialTheme.typography.headlineLarge)
                    Text("Ваши влоги и общие моменты", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                FilledIconButton(onClick = onCreate) { Icon(Icons.Default.Add, "Создать комнату") }
            }
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("Мои", "Совместные", "Открытые").size) { index ->
                    FilterChip(filter == index, { onFilter(index) },
                        label = { Text(listOf("Мои", "Совместные", "Открытые")[index]) })
                }
            }
        }
        if (filter == 1) item {
            MomentoRoomTile("События и секретные комнаты", "Общие воспоминания с близкими",
                "", onClick = onSpecialRooms, icon = Icons.Outlined.Group)
        }
        if (filter == 2) {
            item { OutlinedTextField(search, { search = it.take(100) }, Modifier.fillMaxWidth(),
                singleLine = true, label = { Text("Поиск открытых комнат") }) }
            if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
            if (failed) item { MomentoStatePanel("Не удалось загрузить комнаты", "Проверь подключение к интернету.",
                "Повторить", { refresh++ }, isError = true) }
            if (!failed && !loading && entries.isEmpty()) item {
                MomentoStatePanel("Открытых комнат пока нет", "Попробуй изменить запрос.",
                    illustration = R.drawable.momento_art_rooms)
            }
            if (actionFailed) item { Text("Не удалось обновить подписку.", color = MaterialTheme.colorScheme.error) }
            if (!failed && !loading) items(entries.distinctBy { it.id }, key = { it.id }) { room ->
                MomentoRoomTile(room.name, room.description, "Открытая комната", onClick = { onOpenPublic(room.id) },
                    icon = Icons.Outlined.Language)
                TextButton(enabled = changing == null, onClick = {
                    changing = room.id
                    actionFailed = false
                    val follow = room.id !in subscribed
                    scope.launch {
                        try {
                            api.setRoomFollow(accessToken, room.id, follow)
                            subscribed = if (follow) subscribed + room.id else subscribed - room.id
                        } catch (cancelled: CancellationException) {
                            throw cancelled
                        } catch (_: Exception) {
                            actionFailed = true
                        } finally { changing = null }
                    }
                }) { Text(if (room.id in subscribed) "Отписаться" else "Подписаться") }
            }
        } else {
            if (local.isEmpty() && filter == 0) item {
                MomentoStatePanel("Пока нет комнат", "Создай первую комнату для своих воспоминаний.",
                    illustration = R.drawable.momento_art_rooms)
            }
            items(local, key = { it.id }) { room ->
                val (label, icon) = when (room.visibility) {
                    "PUBLIC" -> "Открытая" to Icons.Outlined.Language
                    "LINK" -> "Совместная" to Icons.Outlined.Group
                    else -> "Личная" to Icons.Outlined.Lock
                }
                MomentoRoomTile(room.name, room.description, label,
                    onClick = { onOpen(room.id) }, icon = icon,
                    footer = "Черновик".takeIf { room.status == "DRAFT" })
            }
            item { MomentoRoomTile("Создать комнату", "Новый влог для ваших моментов", "", onClick = onCreate) }
        }
    }
}

@Composable
fun SubscriptionsPlaceholderScreen() {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Подписки", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Здесь появятся продолжения влогов после подключения сервера и авторизации подписок.")
        Text("Пока публичные комнаты не загружены. Личные комнаты других пользователей недоступны.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
