package ru.momento.app.ui

import ru.momento.app.R
import ru.momento.app.ui.designsystem.Vlog3DGlassCard
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PersonOutline
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Button
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.credentials.ClearCredentialStateRequest
import com.vk.id.VKID
import com.vk.id.logout.VKIDLogoutCallback
import com.vk.id.logout.VKIDLogoutFail
import android.net.Uri
import android.widget.VideoView
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import ru.momento.app.data.LocalMoment
import ru.momento.app.data.LocalMomentDatabase
import ru.momento.app.data.LocalSpace
import ru.momento.app.data.LocalSpaceDatabase
import ru.momento.app.network.MomentoSessionVault
import ru.momento.app.network.MomentoApiClient
import ru.momento.app.network.MomentoAuthClient
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class Tab(val label: String) {
    SPACES("Комнаты"), SPECIAL_ROOMS("События и секретные комнаты"), SPECIAL_RECORD("Запись в комнату"), SUBSCRIPTIONS("Подписки"), CREATE("Создать"), MINE("Мои"), SEARCH("Поиск"), PROFILE("Профиль"), SETTINGS("Настройки"), ARCHIVE("Архив"), CALENDAR("Календарь"), FILM("Жизнь в секундах"), CAPSULES("Капсулы"), RECORD("Момент"), ROOM_DETAIL("Комната"), ROOM_PLAYER("Просмотр")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MomentoApp() {
    val launchActivity = androidx.activity.compose.LocalActivity.current
    val initialRoom = launchActivity?.intent?.getStringExtra("record_room_id")
    var selectedTab by rememberSaveable { mutableStateOf(Tab.RECORD) }
    var roomsFilter by rememberSaveable { mutableIntStateOf(0) }
    var creatingRoom by remember { mutableStateOf(false) }
    var roomCreationFromCamera by rememberSaveable { mutableStateOf(false) }
    var archiveError by rememberSaveable { mutableStateOf<String?>(null) }
    val notificationPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) archiveError = "Уведомления отключены. Разреши их в настройках Android."
    }
    val context = LocalContext.current
    val exactAlarmSettingsLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) {
        ru.momento.app.data.RoomAlarmScheduler.rescheduleAll(context)
        archiveError = if (ru.momento.app.data.RoomAlarmScheduler.canUseExactAlarms(context))
            "Точные напоминания разрешены" else "Уведомления могут приходить с задержкой"
    }
    val sessionVault = remember(context) { MomentoSessionVault(context) }
    var authSession by remember { mutableStateOf(sessionVault.read()) }
    var logoutBusy by remember { mutableStateOf(false) }
    val authClient = remember { MomentoAuthClient(ru.momento.app.BuildConfig.MOMENTO_API_BASE_URL) }
    LaunchedEffect(authSession?.refreshToken) {
        val initial = authSession ?: return@LaunchedEffect
        val expectedToken = initial.refreshToken
        while (authSession?.refreshToken == expectedToken) {
            val waitMillis = initial.expiresAtMillis - System.currentTimeMillis() - 60_000L
            if (waitMillis > 0L) delay(waitMillis)
            if (authSession?.refreshToken != expectedToken) break
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val owner = sessionVault.readVerifiedAccountId()
                    if (owner == null) null
                    else ru.momento.app.network.MomentoSessionRefresh.refreshForOwner(sessionVault, owner)
                }
            }
            val refreshed = result.getOrNull()
            if (refreshed != null) {
                // The worker may have refreshed this session first. Do not overwrite it.
                if (sessionVault.read()?.refreshToken == refreshed.refreshToken) authSession = refreshed
                break
            }
            val failure = result.exceptionOrNull()
            if (failure is ru.momento.app.network.MomentoApiException && failure.statusCode == 401) {
                // Never clear a newer session that replaced the rejected token.
                if (sessionVault.read()?.refreshToken == expectedToken) {
                    withContext(Dispatchers.IO) { sessionVault.clear() }
                    authSession = null
                }
                break
            }
            delay(15_000L)
        }
    }
    val onboardingPrefs = remember(context) { context.getSharedPreferences("momento_onboarding", 0) }
    var onboardingComplete by rememberSaveable {
        mutableStateOf(onboardingPrefs.getBoolean("complete", false))
    }
    if (authSession == null && !onboardingComplete) {
        MomentoIntroduction {
            onboardingComplete = true
            onboardingPrefs.edit().putBoolean("complete", true).apply()
        }
        return
    }
    var localPreview by rememberSaveable { mutableStateOf(false) }
    if (authSession == null && localPreview) {
        LocalPreviewScreen { localPreview = false }
        return
    }
    var guestMode by rememberSaveable { mutableStateOf(false) }
    var guestPublishing by rememberSaveable { mutableStateOf(false) }
    var guestLoginOnly by rememberSaveable { mutableStateOf(false) }
    if (authSession == null && guestMode && !guestPublishing) {
        GuestHomeScreen(
            onLocalPreview = { localPreview = true },
            onPublish = { guestPublishing = true; guestLoginOnly = false },
            onSignIn = { guestPublishing = true; guestLoginOnly = true },
            onLeave = { guestMode = false }
        )
        return
    }
    if (authSession == null) {
        if (guestPublishing) {
            androidx.compose.material3.TextButton(onClick = { guestPublishing = false }) {
                Text("Отмена — вернуться в гостевой режим")
            }
            if (!guestLoginOnly) Text("Чтобы записывать и публиковать моменты, сначала войди в аккаунт.", modifier = Modifier.padding(16.dp))
        }
        AuthScreen(vault = sessionVault,
            onAuthenticated = { authSession = it; if (guestPublishing && !guestLoginOnly) selectedTab = Tab.CREATE; guestPublishing = false; guestMode = false },
            onGuest = { guestMode = true; guestPublishing = false },
            onLocalPreview = { localPreview = true })
        return
    }
    // Fail closed until /auth/me verifies which account owns the local archive.
    var verifiedAccountId by remember(authSession?.accessToken) { mutableStateOf(sessionVault.readVerifiedAccountId()) }
    LaunchedEffect(authSession?.accessToken) {
        val token = authSession?.accessToken ?: return@LaunchedEffect
        // A cached, server-verified identity permits offline use of this account's archive.
        // Never replace it with an unverified JWT claim or a different server identity.
        val verified = withContext(Dispatchers.IO) {
            runCatching { authClient.authenticatedUserId(token) }.getOrNull()
        }
        if (verified != null) {
            val cached = sessionVault.readVerifiedAccountId()
            if (cached != null && cached != verified) {
                withContext(Dispatchers.IO) { sessionVault.clear() }
                authSession = null
                return@LaunchedEffect
            }
            val bound = withContext(Dispatchers.IO) { sessionVault.bindVerifiedAccountId(token, verified) }
            if (bound) verifiedAccountId = verified
        }
    }
    if (verifiedAccountId == null) {
        Text("Для первого входа в архив нужен интернет. После подтверждения аккаунта архив будет доступен офлайн.",
            modifier = Modifier.padding(24.dp))
        return
    }
    val accountId = verifiedAccountId!!
    var remindersEnabled by remember(accountId) { mutableStateOf(ru.momento.app.data.RoomAlarmScheduler.isAccountEnabled(context)) }
    LaunchedEffect(accountId) {
        ru.momento.app.data.RoomAlarmScheduler.setAccount(context, accountId)
        remindersEnabled = ru.momento.app.data.RoomAlarmScheduler.isAccountEnabled(context)
    }
    val database = remember(context, accountId) { LocalMomentDatabase(context, accountId) }
    val spacesDatabase = remember(context, accountId) { LocalSpaceDatabase(context, accountId) }
    val scope = rememberCoroutineScope()
    val savedMoments = remember(accountId) { mutableStateListOf<LocalMoment>() }
    val uploadClient = remember { MomentoApiClient() }
    var uploadingMomentId by remember(accountId) { mutableStateOf<String?>(null) }
    val localSpaces = remember(accountId) { mutableStateListOf<LocalSpace>() }
    var publicRoomId by remember(accountId) { mutableStateOf<String?>(null) }
    var sharedRoomId by rememberSaveable(accountId) { mutableStateOf<String?>(null) }
    var sharedRoomName by rememberSaveable(accountId) { mutableStateOf("") }
    var activeRoomId by rememberSaveable(accountId) { mutableStateOf<String?>(initialRoom) }
    var activeRoomLinks by remember(accountId) { mutableStateOf(emptyList<ru.momento.app.data.RoomMomentLink>()) }
    fun refreshRoomLinks(roomId: String) {
        scope.launch {
            val links = withContext(Dispatchers.IO) { spacesDatabase.momentsForRoom(roomId) }
            if (activeRoomId == roomId) activeRoomLinks = links
        }
    }
    fun openRoom(roomId: String) {
        if (activeRoomId != roomId) activeRoomLinks = emptyList()
        activeRoomId = roomId
        refreshRoomLinks(roomId)
        selectedTab = Tab.ROOM_DETAIL
    }
    // Resume only owner-approved QUEUED uploads; no automatic publication to rooms.
    LaunchedEffect(database, accountId) {
        val queued = withContext(Dispatchers.IO) { database.queuedMoments().isNotEmpty() || database.sharedRoomSyncItems().isNotEmpty() }
        if (queued) ru.momento.app.data.MomentUploadWorker.enqueue(context, accountId)
    }
    LaunchedEffect(database) {
        val records = withContext(Dispatchers.IO) { database.recoverUnindexedCaptures(context); database.getMoments() }
        savedMoments.clear()
        savedMoments.addAll(records)
    }
    LaunchedEffect(spacesDatabase) {
        val rooms = withContext(Dispatchers.IO) { spacesDatabase.getSpaces() }
        localSpaces.clear()
        localSpaces.addAll(rooms)
        if (activeRoomId == null || rooms.none { it.id == activeRoomId }) {
            activeRoomId = rooms.firstOrNull { it.status != "COMPLETED" && it.status != "DELETED" }?.id
        }
        ru.momento.app.data.RoomAlarmScheduler.reconcile(
            context, rooms.filter { it.status != "COMPLETED" && it.status != "DELETED" }.map { it.id }.toSet()
        )
    }
    // WorkManager writes to SQLite outside Compose state. Refresh only while the
    // archive is visible and uploads are pending; otherwise the UI can show
    // "Отправляется" forever after the background worker has finished.
    LaunchedEffect(database, selectedTab) {
        if (selectedTab != Tab.ARCHIVE) return@LaunchedEffect
        while (true) {
            delay(2_000L)
            val latest = withContext(Dispatchers.IO) { database.getMoments() }
            if (latest != savedMoments.toList()) {
                savedMoments.clear()
                savedMoments.addAll(latest)
            }
        }
    }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            if (selectedTab != Tab.RECORD && selectedTab != Tab.SPECIAL_RECORD) TopAppBar(
                title = {
                    MomentoBrand()
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        bottomBar = {
            if (selectedTab != Tab.RECORD && selectedTab != Tab.SPECIAL_RECORD && selectedTab != Tab.ROOM_PLAYER && selectedTab != Tab.CREATE && selectedTab != Tab.SETTINGS && publicRoomId == null) {
            val mainTabs = listOf(Tab.RECORD, Tab.SPACES, Tab.SUBSCRIPTIONS, Tab.PROFILE)
            val mainTab = when (selectedTab) {
                Tab.ARCHIVE, Tab.CALENDAR, Tab.FILM, Tab.CAPSULES, Tab.SETTINGS -> Tab.PROFILE
                Tab.CREATE, Tab.MINE, Tab.SEARCH, Tab.SPECIAL_ROOMS, Tab.SPECIAL_RECORD,
                Tab.ROOM_DETAIL, Tab.ROOM_PLAYER -> Tab.SPACES
                else -> selectedTab
            }
            MomentoNavigationBar(mainTabs.indexOf(mainTab)) { index ->
                selectedTab = mainTabs[index]
            }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            archiveError?.let { message ->
                Text(message, color = MaterialTheme.colorScheme.error, modifier = Modifier.fillMaxWidth().padding(12.dp))
            }
            when (selectedTab) {
            Tab.SPACES -> {
                val opened = publicRoomId
                if (opened != null) PublicRoomScreen(authSession!!.accessToken, opened, uploadClient,
                    onBack = { publicRoomId = null })
                else {
                    val roomSnapshot = localSpaces.toList()
                    val momentSnapshot = savedMoments.toList()
                    var roomMoments by remember(accountId) { mutableStateOf<Map<String, List<LocalMoment>>>(emptyMap()) }
                    LaunchedEffect(spacesDatabase, roomSnapshot, momentSnapshot) {
                        roomMoments = withContext(Dispatchers.IO) {
                            val byId = momentSnapshot.associateBy { it.id }
                            roomSnapshot.associate { room ->
                                room.id to spacesDatabase.momentsForRoom(room.id).mapNotNull { byId[it.momentId] }
                            }
                        }
                    }
                    LiveHomeScreen(
                    rooms = roomSnapshot,
                    roomMoments = roomMoments,
                    accessToken = authSession!!.accessToken,
                    api = uploadClient,
                    filter = roomsFilter,
                    onFilter = { roomsFilter = it },
                    onCreate = { selectedTab = Tab.CREATE },
                    onSpecialRooms = { selectedTab = Tab.SPECIAL_ROOMS },
                    onOpen = ::openRoom,
                    onPlay = { id ->
                        activeRoomId = id
                        activeRoomLinks = emptyList()
                        refreshRoomLinks(id)
                        selectedTab = Tab.ROOM_PLAYER
                    },
                    onOpenPublic = { publicRoomId = it }
                    )
                }
            }
            Tab.SPECIAL_ROOMS -> androidx.compose.runtime.key(accountId) {
                SpecialRoomsScreen(authSession?.accessToken.orEmpty(), accountId, uploadClient, onRecord = { id, name ->
                    sharedRoomId = id
                    sharedRoomName = name
                    selectedTab = Tab.SPECIAL_RECORD
                }, onBack = { selectedTab = Tab.SPACES })
            }
            Tab.SPECIAL_RECORD -> {
                val destination = sharedRoomId
                if (destination == null) {
                    TextButton(onClick = { selectedTab = Tab.SPECIAL_ROOMS }) { Text("К комнатам") }
                } else CameraScreen(
                    verifiedOwnerId = accountId,
                    roomNames = listOf(destination to sharedRoomName),
                    selectedRoomId = destination,
                    onSaved = { file, duration ->
                        scope.launch {
                            val saved = runCatching {
                                withContext(Dispatchers.IO) {
                                    val moment = database.insertMoment(file, duration)
                                    database.queueSharedRoomMoment(moment.id, destination)
                                    moment
                                }
                            }
                            saved.onSuccess {
                                savedMoments.add(0, it)
                                ru.momento.app.data.MomentUploadWorker.enqueue(context, accountId)
                                selectedTab = Tab.SPECIAL_ROOMS
                            }.onFailure {
                                archiveError = "Видео осталось на устройстве. Не удалось поставить его в очередь комнаты."
                            }
                        }
                    },
                    onClose = { selectedTab = Tab.SPECIAL_ROOMS }
                )
            }
            Tab.SUBSCRIPTIONS -> {
                val opened = publicRoomId
                if (opened == null) SubscriptionsScreen(authSession!!.accessToken, uploadClient,
                    onOpenRoom = { publicRoomId = it },
                    onFindRooms = { roomsFilter = 2; selectedTab = Tab.SPACES })
                else PublicRoomScreen(authSession!!.accessToken, opened, uploadClient,
                    onBack = { publicRoomId = null })
            }
            Tab.MINE -> MyRoomsScreen(localSpaces, onCreate = { selectedTab = Tab.CREATE }, onOpen = ::openRoom)
            Tab.SEARCH -> RoomSearchScreen(localSpaces, onOpen = ::openRoom)
            Tab.CREATE -> CreateRoomScreen(
                saving = creatingRoom,
                onSave = { name, description, visibility, topic ->
                    if (creatingRoom) return@CreateRoomScreen
                    creatingRoom = true
                    scope.launch {
                        val result = runCatching {
                            withContext(Dispatchers.IO) { spacesDatabase.createRoom(name, description, visibility, topic) }
                        }
                        result.onSuccess {
                            localSpaces.add(0, it)
                            activeRoomId = it.id
                            archiveError = null
                            selectedTab = if (roomCreationFromCamera) Tab.RECORD else Tab.MINE
                            roomCreationFromCamera = false
                        }.onFailure { archiveError = "Не удалось сохранить комнату. Попробуй снова." }
                        creatingRoom = false
                    }
                },
                onCancel = {
                    selectedTab = if (roomCreationFromCamera) Tab.RECORD else Tab.SPACES
                    roomCreationFromCamera = false
                }
            )
            Tab.ROOM_DETAIL -> {
                val room = localSpaces.firstOrNull { it.id == activeRoomId }
                if (room == null) Text("Комната не найдена") else RoomMomentsScreen(
                    room, savedMoments, activeRoomLinks,
                    onRemove = { id -> scope.launch {
                        withContext(Dispatchers.IO) { spacesDatabase.removeMoment(room.id, id) }; refreshRoomLinks(room.id)
                    } },
                    onSeries = { id, series -> scope.launch {
                        withContext(Dispatchers.IO) { spacesDatabase.setSeries(room.id, id, series) }; refreshRoomLinks(room.id)
                    } },
                    onPlay = { selectedTab = Tab.ROOM_PLAYER },
                    onRecord = { selectedTab = Tab.RECORD },
                    onPublish = {
                        scope.launch {
                            val result = runCatching { withContext(Dispatchers.IO) {
                                spacesDatabase.requestPublication(room.id)
                                spacesDatabase.momentsForRoom(room.id).forEach { link ->
                                    database.markForRoomSync(link.momentId,room.id)
                                    val moment = database.getMoments().firstOrNull { it.id == link.momentId }
                                    if (moment?.remoteMomentId == null) database.queueUpload(link.momentId)
                                }
                            } }
                            result.onSuccess {
                                localSpaces.clear(); localSpaces.addAll(withContext(Dispatchers.IO) { spacesDatabase.getSpaces() })
                                ru.momento.app.data.MomentUploadWorker.enqueue(context,accountId)
                                archiveError = "Публикация поставлена в очередь. Локальные файлы сохранены."
                            }.onFailure { archiveError = "Не удалось поставить в очередь: ${it.message}" }
                        }
                    },
                    onBack = { selectedTab = Tab.MINE }
                )
            }
            Tab.ROOM_PLAYER -> {
                val room = localSpaces.firstOrNull { it.id == activeRoomId }
                if (room == null) Text("Комната не найдена") else RoomVlogPlayer(
                    room, activeRoomLinks.mapNotNull { link -> savedMoments.firstOrNull { it.id == link.momentId } },
                    onBack = { selectedTab = Tab.ROOM_DETAIL }
                )
            }
            Tab.ARCHIVE -> ArchiveScreen(PaddingValues(0.dp), savedMoments, uploadingMomentId) { moment ->
                if (uploadingMomentId != null || authSession?.accessToken.isNullOrBlank()) return@ArchiveScreen
                uploadingMomentId = moment.id
                scope.launch {
                    val result = runCatching {
                        withContext(Dispatchers.IO) { database.queueUpload(moment.id) }
                        // A single WorkManager owner handles all network uploads.
                        // UI must never race it with a second direct HTTP request.
                        ru.momento.app.data.MomentUploadWorker.enqueue(context, accountId)
                    }
                    archiveError = if (result.isFailure) "Не удалось поставить момент в очередь." else null
                    savedMoments.clear()
                    savedMoments.addAll(withContext(Dispatchers.IO) { database.recoverUnindexedCaptures(context); database.getMoments() })
                    uploadingMomentId = null
                }
            }
            Tab.CALENDAR -> LifeCalendarScreen(savedMoments)
            Tab.FILM -> androidx.compose.runtime.key(accountId) {
                LifeFilmScreen(accountId, savedMoments) { selectedTab = Tab.PROFILE }
            }
            Tab.CAPSULES -> CapsulesScreen(authSession?.accessToken.orEmpty(), remember { ru.momento.app.network.MomentoApiClient() })
            Tab.RECORD -> CameraScreen(
                verifiedOwnerId = accountId,
                onArchive = { selectedTab = Tab.ARCHIVE },
                roomNames = localSpaces.map { it.id to it.name },
                selectedRoomId = activeRoomId,
                onRoomSelected = { activeRoomId = it },
                onCreateRoom = { roomCreationFromCamera = true; selectedTab = Tab.CREATE },
                bottomNavigation = { enabled ->
                    MomentoNavigationBar(0, enabled) { index ->
                        selectedTab = listOf(Tab.RECORD, Tab.SPACES, Tab.SUBSCRIPTIONS, Tab.PROFILE)[index]
                    }
                },
                onSaved = { file, durationMillis ->
                    val destinationRoom = activeRoomId
                    scope.launch {
                        val record = runCatching {
                            withContext(Dispatchers.IO) { database.insertMoment(file, durationMillis) }
                        }.getOrElse {
                            archiveError = "Видео осталось на устройстве, но не удалось добавить его в архив. Перезапусти приложение."
                            return@launch
                        }
                        archiveError = null
                        savedMoments.add(0, record)
                        if (destinationRoom != null) {
                            val roomId = destinationRoom
                            runCatching { withContext(Dispatchers.IO) { spacesDatabase.addMoment(roomId, record.id) } }
                                .onFailure { archiveError = "Видео сохранено, но не добавлено в комнату" }
                            // A published public room is an ongoing vlog: newly captured moments
                            // join its durable upload queue without another publish button.
                            val currentRoom = localSpaces.firstOrNull { it.id == roomId }
                            if (currentRoom?.visibility == "PUBLIC" && currentRoom.status == "PUBLISHED") {
                                val queued = runCatching { withContext(Dispatchers.IO) {
                                    database.markForRoomSync(record.id, roomId)
                                    database.queueUpload(record.id)
                                } }.isSuccess
                                if (queued) ru.momento.app.data.MomentUploadWorker.enqueue(context, accountId)
                                else archiveError = "Момент сохранён локально, но не поставлен в очередь."
                            }
                            refreshRoomLinks(roomId)
                            selectedTab = Tab.ROOM_DETAIL
                        } else selectedTab = Tab.ARCHIVE
                    }
                },
                onClose = { selectedTab = if (activeRoomId != null) Tab.ROOM_DETAIL else Tab.PROFILE }
            )
            Tab.SETTINGS -> MomentoSettings(
                onBack = { selectedTab = Tab.PROFILE },
                onSubscriptions = { selectedTab = Tab.SUBSCRIPTIONS },
                reminders = {
                    MomentoReminderPolicyCard(
                    enabled = remindersEnabled,
                    onToggle = { enabled ->
                        if (enabled) {
                            ru.momento.app.data.RoomAlarmScheduler.setEnabled(context, true)
                            remindersEnabled = true
                            if (android.os.Build.VERSION.SDK_INT >= 33 &&
                                androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                                notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            ru.momento.app.data.RoomAlarmScheduler.setEnabled(context, false)
                            remindersEnabled = false
                        }
                    },
                    permissionGranted = android.os.Build.VERSION.SDK_INT < 33 ||
                        androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    )
                }
            )
            Tab.PROFILE -> androidx.compose.foundation.lazy.LazyColumn(Modifier.fillMaxSize(),
                contentPadding = PaddingValues(MomentoTokens.screenPadding), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                item { MomentoProfileHeader("Профиль", "Личные моменты, настройки аккаунта и напоминания.") }
                item {
                    VideoAvatarSection(savedMoments)
                }
                item { ProfileAuthSection(
                    accessToken = authSession?.accessToken.orEmpty(),
                    client = authClient,
                    busy = logoutBusy,
                    onLogout = {
                        logoutBusy = true
                        scope.launch {
                            runCatching {
                                withContext(Dispatchers.IO) { authClient.logout(authSession?.refreshToken.orEmpty()) }
                            }
                            runCatching {
                                CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest())
                            }
                            if (ru.momento.app.BuildConfig.VK_CLIENT_ID.isNotBlank()) {
                                runCatching {
                                    VKID.instance.logout(object : VKIDLogoutCallback {
                                        override fun onSuccess() = Unit
                                        override fun onFail(fail: VKIDLogoutFail) = Unit
                                    })
                                }
                            }
                            withContext(Dispatchers.IO) { sessionVault.clear() }
                            ru.momento.app.data.RoomAlarmScheduler.disableAll(context)
                            authSession = null
                            logoutBusy = false
                        }
                    }
                ) }
                item { MomentoRoomTile("Настройки", "Напоминания, приватность, воспроизведение и тема", "",
                    onClick = { selectedTab = Tab.SETTINGS }) }
                item { MomentoSectionTitle("Мои материалы") }
                item { Button(onClick = { selectedTab = Tab.ARCHIVE }) { Text("Личный архив моментов") } }
                item { Button(onClick = { selectedTab = Tab.CALENDAR }) { Text("Календарь жизни") } }
                item { MomentoFilmCard { selectedTab = Tab.FILM } }
                item { Button(onClick = { selectedTab = Tab.CAPSULES }) { Text("Капсулы времени") } }
                item { MomentoPrimaryAction("Записать личный момент", onClick = { activeRoomId = null; selectedTab = Tab.RECORD }) }
                /* Button(onClick = { activeRoomId = null; selectedTab = Tab.RECORD }) { Text("Записать личный момент") }
                Button(onClick = { selectedTab = Tab.SPACES }) { Text("Вернуться к комнатам") } */
            }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    padding: PaddingValues,
    moments: List<LocalMoment>,
    roomCount: Int,
    onRecordClick: () -> Unit,
    onArchiveClick: () -> Unit,
    onRoomsClick: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Твоя жизнь — в моментах", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Сохраняй короткие видео и делись ими с близкими.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onRecordClick() },
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Поймай момент", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("Всего несколько секунд — воспоминание останется с тобой.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Box(Modifier.size(54.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
                    }
                }
            }
        }
        item { SectionTitle("Недавние моменты", "Всего сохранено: ${moments.size}") }
        if (moments.isEmpty()) {
            item { EmptyCard("Твои первые моменты появятся здесь") }
        } else {
            items(moments.take(3), key = { "home_${it.id}" }) { moment ->
                Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onArchiveClick)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(SimpleDateFormat("d MMMM yyyy · HH:mm", Locale("ru", "RU"))
                            .format(Date(moment.capturedAtMillis)), fontWeight = FontWeight.SemiBold)
                        Text("${moment.durationMillis / 1000.0} сек · Открыть в архиве",
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onRoomsClick)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Твои комнаты", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(if (roomCount == 0) "Пока нет комнат · Создать комнату"
                         else "Комнат на устройстве: $roomCount · Открыть",
                         color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
internal fun ArchiveScreen(
    padding: PaddingValues,
    moments: List<LocalMoment>,
    uploadingMomentId: String?,
    onRecord: (() -> Unit)? = null,
    onUpload: ((LocalMoment) -> Unit)? = null
) {
    if (moments.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(padding).padding(MomentoTokens.screenPadding)) {
            MomentoStatePanel("Мой архив", "Запиши видео на 2–5 секунд. Первый момент появится здесь.",
                if (onRecord != null) "Открыть камеру" else null, onRecord,
                illustration = R.drawable.momento_art_moments)
        }
        return
    }
    var playingId by remember(moments.isEmpty()) { mutableStateOf<String?>(null) }
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Мой архив", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        items(moments, key = { it.id }) { moment ->
            val file = moment.file
            Vlog3DGlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(
                        SimpleDateFormat("d MMMM yyyy · HH:mm", Locale("ru", "RU")).format(Date(moment.capturedAtMillis)),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(8.dp))
                    if (playingId == moment.id && file.isFile) {
                        androidx.compose.runtime.key(moment.id) {
                            AndroidView(
                                factory = { context -> VideoView(context).apply {
                                    setVideoURI(Uri.fromFile(file))
                                    setMediaController(android.widget.MediaController(context))
                                    start()
                                } },
                                onReset = null,
                                onRelease = { it.stopPlayback() },
                                modifier = Modifier.fillMaxWidth().height(220.dp)
                            )
                        }
                        TextButton(onClick = { playingId = null }) { Text("Закрыть видео") }
                    } else if (file.isFile) {
                        TextButton(onClick = { playingId = moment.id }) { Text("Смотреть момент") }
                    } else {
                        Text("Файл момента отсутствует на устройстве.", color = MaterialTheme.colorScheme.error)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Личный архив · ${moment.durationMillis / 1000.0} с · ${moment.byteSize / 1024} КБ", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    if (onUpload == null) {
                        Text("Хранится на этом устройстве", style = MaterialTheme.typography.bodySmall)
                    } else if (moment.uploadState == LocalMomentDatabase.UPLOAD_UPLOADED_PRIVATE) {
                        Text("Сохранено в личном облачном архиве", color = MaterialTheme.colorScheme.primary)
                    } else {
                        Button(
                            onClick = { onUpload(moment) },
                            enabled = uploadingMomentId == null && moment.file.isFile
                        ) {
                            Text(when {
                                uploadingMomentId == moment.id -> "Добавление в очередь…"
                                moment.uploadState == LocalMomentDatabase.UPLOAD_QUEUED -> "В очереди · повторить"
                                moment.uploadState == LocalMomentDatabase.UPLOAD_UPLOADING -> "Отправляется · повторить позже"
                                moment.uploadState == LocalMomentDatabase.UPLOAD_FAILED -> "Повторить загрузку"
                                else -> "Загрузить в личный архив"
                            })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SpacesScreen(
    padding: PaddingValues,
    spaces: List<LocalSpace>,
    onCreateSpace: (String) -> Unit
) {
    var showCreateDialog by rememberSaveable { mutableStateOf(false) }
    var roomName by rememberSaveable { mutableStateOf("") }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Новая комната") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Создай пространство для общих коротких видео.")
                    OutlinedTextField(
                        value = roomName,
                        onValueChange = { roomName = it.take(60) },
                        label = { Text("Название комнаты") },
                        singleLine = true,
                        supportingText = { Text("До 60 символов") }
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = roomName.trim().isNotEmpty(),
                    onClick = {
                        onCreateSpace(roomName)
                        roomName = ""
                        showCreateDialog = false
                    }
                ) { Text("Создать") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Отмена") }
            }
        )
    }

    Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp, vertical = 12.dp)) {
        Text("Комнаты", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Общие моменты с теми, кто тебе важен.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(18.dp))
        Button(onClick = { showCreateDialog = true }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.size(8.dp))
            Text("Создать комнату")
        }
        Spacer(Modifier.height(20.dp))
        Text("Мои комнаты", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        if (spaces.isEmpty()) {
            EmptyCard("Здесь появятся комнаты, в которых ты участвуешь. Создай первую — для семьи, друзей или близких.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(spaces, key = { it.id }) { space ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(space.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text("Создана ${SimpleDateFormat("d MMM yyyy · HH:mm", Locale("ru", "RU")).format(Date(space.createdAtMillis))}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Сохранена на этом устройстве · синхронизация ещё не подключена", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "Приглашения и общая лента появятся после подключения сервера. Сейчас комнаты сохраняются локально — приложение не создаёт неработающие ссылки или фиктивные приглашения.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SimpleScreen(padding: PaddingValues, title: String, subtitle: String) {
    Column(
        Modifier.fillMaxSize().padding(padding).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EmptyCard(message: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Box(Modifier.fillMaxWidth().padding(22.dp), contentAlignment = Alignment.Center) {
            Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
