# Реестр собственных ресурсов

Графика создана для MOMENTO. Внешние модели, лицензии библиотек или стоковые активы в этих файлах не используются.

| Ресурс | Экран | Формат и размер | Редактируемый источник |
|---|---|---|---|
| momento_render_error.webp | Ошибка загрузки | WebP 251 × 198, 7232 байт | design-assets/3d/error.blend |
| momento_render_offline.webp | Подготовленная иллюстрация офлайн-состояния | WebP 251 × 198, 5688 байт | design-assets/3d/offline.blend |
| momento_render_people.webp | Onboarding о сообществах | WebP 304 × 254, 8874 байт | design-assets/3d/people.blend |
| momento_render_reminder.webp | Напоминания | WebP 241 × 223, 7348 байт | design-assets/3d/reminder.blend |
| momento_render_rooms.webp | Комнаты и создание | WebP 287 × 238, 7432 байт | design-assets/3d/rooms.blend |
| momento_render_save.webp | Onboarding и пустой архив | WebP 319 × 240, 8712 байт | design-assets/3d/save.blend |
| momento_render_share.webp | Onboarding о близких | WebP 319 × 240, 9622 байт | design-assets/3d/share.blend |
| momento_render_shield.webp | Приватность | WebP 238 × 222, 6734 байт | design-assets/3d/shield.blend |
| momento_render_subscriptions.webp | Пустые подписки | WebP 292 × 240, 8124 байт | design-assets/3d/subscriptions.blend |
| momento_ic_archive | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_archive.svg |
| momento_ic_back | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_back.svg |
| momento_ic_bell | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_bell.svg |
| momento_ic_calendar | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_calendar.svg |
| momento_ic_camera | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_camera.svg |
| momento_ic_camera_filled | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_camera_filled.svg |
| momento_ic_camera_switch | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_camera_switch.svg |
| momento_ic_check | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_check.svg |
| momento_ic_chevron_down | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_chevron_down.svg |
| momento_ic_chevron_right | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_chevron_right.svg |
| momento_ic_clock | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_clock.svg |
| momento_ic_close | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_close.svg |
| momento_ic_flash | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_flash.svg |
| momento_ic_folder_plus | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_folder_plus.svg |
| momento_ic_fullscreen | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_fullscreen.svg |
| momento_ic_globe | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_globe.svg |
| momento_ic_heart | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_heart.svg |
| momento_ic_heart_filled | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_heart_filled.svg |
| momento_ic_hourglass | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_hourglass.svg |
| momento_ic_info | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_info.svg |
| momento_ic_lock | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_lock.svg |
| momento_ic_mic | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_mic.svg |
| momento_ic_mic_off | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_mic_off.svg |
| momento_ic_moon | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_moon.svg |
| momento_ic_more | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_more.svg |
| momento_ic_pause | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_pause.svg |
| momento_ic_play | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_play.svg |
| momento_ic_plus | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_plus.svg |
| momento_ic_profile | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_profile.svg |
| momento_ic_profile_filled | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_profile_filled.svg |
| momento_ic_refresh | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_refresh.svg |
| momento_ic_rooms | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_rooms.svg |
| momento_ic_rooms_filled | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_rooms_filled.svg |
| momento_ic_search | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_search.svg |
| momento_ic_settings | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_settings.svg |
| momento_ic_shield | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_shield.svg |
| momento_ic_stop | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_stop.svg |
| momento_ic_users | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_users.svg |
| momento_ic_video | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_video.svg |
| momento_ic_volume | Иконки и debug-каталог | SVG / VectorDrawable 24 × 24 | design-assets/icons/momento_ic_volume.svg |
| Знак MOMENTO | Верхняя панель, splash, welcome | SVG / VectorDrawable 32 × 32 | design-assets/logo/momento.svg |
| Обложка | Профиль | SVG / VectorDrawable 360 × 132 | design-assets/illustrations/profile_cover.svg |
