# V4 · исследование графических подходов

GitHub API проверен 26.11.2026. Дата отражает последнее изменение репозитория. Код из списка не заимствован, зависимостей не добавлено. Совместимость приложений и рендереров как проекта не заявляется без интеграционной сборки. В APK остаются собственные Compose Canvas, VectorDrawable и статические WebP.

## Compose

| Репозиторий | Лицензия по GitHub | Последнее изменение | Роль в решении |
|---|---|---|---|
| [android/compose-samples](https://github.com/android/compose-samples) | Apache-2.0 | 2026-11-25 | Адаптивные панели и композиция |
| [android/nowinandroid](https://github.com/android/nowinandroid) | Apache-2.0 | 2026-11-25 | Токены и адаптивность |
| [android/user-interface-samples](https://github.com/android/user-interface-samples) | Apache-2.0 | 2025-07-11 · архив | Системные отступы и совместимость |
| [android/architecture-samples](https://github.com/android/architecture-samples) | Apache-2.0 | 2026-11-25 | Сохранение состояния и разделение UI |
| [SmartToolFactory/Jetpack-Compose-Tutorials](https://github.com/SmartToolFactory/Jetpack-Compose-Tutorials) | Apache-2.0 | 2026-09-10 | Canvas и градиенты |
| [canopas/compose-animations-examples](https://github.com/canopas/compose-animations-examples) | проверить LICENSE | 2024-12-26 | Анимации состояния |
| [androidx/androidx](https://github.com/androidx/androidx) | Apache-2.0 | 2026-11-26 | Семантика и Compose Animation |
| [material-components/material-components-android](https://github.com/material-components/material-components-android) | Apache-2.0 | 2026-11-25 | Группировка элементов |
| [wasabeef/awesome-android-ui](https://github.com/wasabeef/awesome-android-ui) | MIT | 2026-06-05 | Каталог Android UI |
## Иконки

| Репозиторий | Лицензия по GitHub | Последнее изменение | Роль в решении |
|---|---|---|---|
| [google/material-design-icons](https://github.com/google/material-design-icons) | Apache-2.0 | 2026-10-23 | Сетка 24 dp |
| [lucide-icons/lucide](https://github.com/lucide-icons/lucide) | NOASSERTION | 2026-11-25 | Скруглённые штрихи |
| [tabler/tabler-icons](https://github.com/tabler/tabler-icons) | MIT | 2026-11-25 | Геометрия тонкого контура |
| [phosphor-icons/core](https://github.com/phosphor-icons/core) | MIT | 2026-01-06 | Активные и контурные версии |
| [microsoft/fluentui-system-icons](https://github.com/microsoft/fluentui-system-icons) | MIT | 2026-11-24 | Согласованная оптическая масса |
## Графика

| Репозиторий | Лицензия по GitHub | Последнее изменение | Роль в решении |
|---|---|---|---|
| [airbnb/lottie-android](https://github.com/airbnb/lottie-android) | Apache-2.0 | 2026-02-15 | Анимации из файлов |
| [rive-app/rive-android](https://github.com/rive-app/rive-android) | MIT | 2026-11-26 | Машины состояний анимации |
| [google/filament](https://github.com/google/filament) | Apache-2.0 | 2026-11-25 | Рендер и профилирование 3D |
| [sceneview/sceneview](https://github.com/sceneview/sceneview) | Apache-2.0 | 2026-11-26 | 3D в Compose |
| [blender/blender](https://github.com/blender/blender) | NOASSERTION | 2026-11-26 | Оригинальные сцены и офлайн-рендер |
| [KhronosGroup/glTF-Sample-Assets](https://github.com/KhronosGroup/glTF-Sample-Assets) | проверить LICENSE | 2026-11-20 | Форматы и лицензии отдельных моделей |
| [KhronosGroup/Vulkan-Samples](https://github.com/KhronosGroup/Vulkan-Samples) | Apache-2.0 | 2026-11-23 | Стоимость GPU-компонентов |
| [google/model-viewer](https://github.com/google/model-viewer) | Apache-2.0 | 2026-11-18 | Просмотр glTF |
| [kool-engine/kool](https://github.com/kool-engine/kool) | Apache-2.0 | 2026-11-25 | Kotlin-рендерер |
## Тесты и изображения

| Репозиторий | Лицензия по GitHub | Последнее изменение | Роль в решении |
|---|---|---|---|
| [cashapp/paparazzi](https://github.com/cashapp/paparazzi) | Apache-2.0 | 2026-11-25 | Снимки без эмулятора |
| [takahirom/roborazzi](https://github.com/takahirom/roborazzi) | Apache-2.0 | 2026-11-24 | Сравнение снимков |
| [pedrovgs/Shot](https://github.com/pedrovgs/Shot) | Apache-2.0 | 2026-01-16 | Снимки на устройстве |
| [coil-kt/coil](https://github.com/coil-kt/coil) | Apache-2.0 | 2026-11-25 | Уменьшение и кеш миниатюр |

В приложении применены принципы сетки и контуров, Canvas, адаптивные панели и системные семантики. Blender используется только как инструмент генерации собственной графики. Filament, SceneView, Vulkan, Lottie и Rive оценены как варианты для интерактивной графики. Для статичных иллюстраций они увеличили бы сложность APK. GLB/KTX2/Meshopt применимы при добавлении интерактивных сцен. Для WebP-иллюстраций этот пайплайн не требуется.
