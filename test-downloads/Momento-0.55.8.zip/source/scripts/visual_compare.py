"""Compare an Android screenshot with an inner-screen crop.

Usage: python scripts/visual_compare.py reference.jpg actual.png output/name
Use a crop with the same viewport ratio. Exclude system chrome and dynamic media
from the input crops when inspecting UI differences.
"""
import argparse
from pathlib import Path
from PIL import Image, ImageChops, ImageOps

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reference", type=Path)
    parser.add_argument("screenshot", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    reference = ImageOps.exif_transpose(Image.open(args.reference)).convert("RGB")
    screenshot = ImageOps.exif_transpose(Image.open(args.screenshot)).convert("RGB")
    if abs((reference.width / reference.height) / (screenshot.width / screenshot.height) - 1) > .03:
        parser.error("Viewport ratios differ by more than 3%; recrop the inputs before comparing.")
    reference = reference.resize(screenshot.size, Image.Resampling.LANCZOS)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    Image.blend(screenshot, reference, .5).save(args.output.with_suffix(".overlay.png"))
    ImageChops.difference(screenshot, reference).save(args.output.with_suffix(".diff.png"))

if __name__ == "__main__":
    main()
