"""Generate paired editable SVGs and Android vectors. Run from the repository root."""
from pathlib import Path

ICONS = {
    "camera": "M3 7H7L9 4H15L17 7H21V20H3Z M15.5 13.4A3.5 3.5 0 1 1 8.5 13.4A3.5 3.5 0 1 1 15.5 13.4",
    "video": "M3 6H15V18H3Z M15 10L21 7V17L15 14",
    "rooms": "M3 8H8L10 5H19A2 2 0 0 1 21 7V19H3Z M10 10L15 13L10 16Z",
    "folder_plus": "M3 8H8L10 5H19A2 2 0 0 1 21 7V19H3Z M12 10V16M9 13H15",
    "heart": "M12 20S3 15 3 8.8C3 4 8.7 3.3 12 7C15.3 3.3 21 4 21 8.8C21 15 12 20 12 20Z",
    "profile": "M16 7A4 4 0 1 1 8 7A4 4 0 1 1 16 7 M4 21V19C4 15.7 7.7 14 12 14S20 15.7 20 19V21Z",
    "settings": "M10 3H14L15 6L18 5L20 8L18.5 10.5L21 12V15L18 16L17 19H14L12 21L10 19H7L6 16L3 15V12L5.5 10.5L4 8L6 5L9 6Z M15 12A3 3 0 1 1 9 12A3 3 0 1 1 15 12",
    "bell": "M5 17H19L17 14V9A5 5 0 0 0 7 9V14Z M10 20Q12 22 14 20",
    "search": "M16 10A6 6 0 1 1 4 10A6 6 0 1 1 16 10 M14.5 14.5L20 20",
    "plus": "M12 5V19M5 12H19",
    "close": "M6 6L18 18M18 6L6 18",
    "back": "M20 12H4M10 6L4 12L10 18",
    "chevron_right": "M9 6L15 12L9 18",
    "chevron_down": "M6 9L12 15L18 9",
    "more": "M12 5V5.1M12 12V12.1M12 19V19.1",
    "play": "M8 5L19 12L8 19Z",
    "pause": "M9 6V18M15 6V18",
    "stop": "M6 6H18V18H6Z",
    "camera_switch": "M20 10A8 8 0 0 0 6 6L3 9M3 5V9H7M4 14A8 8 0 0 0 18 18L21 15M17 15H21V19",
    "flash": "M13 3L5 13H11L10 21L19 10H13Z",
    "mic": "M9 6A3 3 0 0 1 15 6V12A3 3 0 0 1 9 12Z M6 11V12A6 6 0 0 0 18 12V11M12 18V21M9 21H15",
    "mic_off": "M9 9V12A3 3 0 0 0 14 14M9 6A3 3 0 0 1 15 6V11M6 11V12A6 6 0 0 0 16 16M18 11V12M12 18V21M9 21H15M3 3L21 21",
    "lock": "M6 10H18V21H6Z M8 10V7A4 4 0 0 1 16 7V10M12 14V17",
    "globe": "M21 12A9 9 0 1 1 3 12A9 9 0 1 1 21 12 M3 12H21M12 3C7 8 7 16 12 21C17 16 17 8 12 3Z",
    "users": "M15 8A3 3 0 1 1 9 8A3 3 0 1 1 15 8 M5 20V18Q5 14 12 14Q19 14 19 18V20Z M4 12Q2 9 5 7M20 12Q22 9 19 7",
    "shield": "M12 3L20 6V11C20 16 16 19 12 21C8 19 4 16 4 11V6Z M8 12L11 15L16 9",
    "calendar": "M4 6H20V21H4Z M4 10H20M8 3V8M16 3V8M8 14H10M14 14H16M8 17H10",
    "clock": "M21 12A9 9 0 1 1 3 12A9 9 0 1 1 21 12 M12 7V12L16 14",
    "hourglass": "M6 3H18M6 21H18M7 3V6Q7 9 12 12Q17 9 17 6V3M7 21V18Q7 15 12 12Q17 15 17 18V21",
    "info": "M21 12A9 9 0 1 1 3 12A9 9 0 1 1 21 12 M12 11V17M12 7V7.1",
    "moon": "M20 15A8.5 8.5 0 0 1 9 4A8.5 8.5 0 1 0 20 15Z",
    "refresh": "M20 10A8 8 0 0 0 6 6L3 9M3 5V9H7M4 14A8 8 0 0 0 18 18L21 15M17 15H21V19",
    "check": "M5 12L10 17L19 7",
    "volume": "M4 9H8L13 5V19L8 15H4Z M17 9Q20 12 17 15M19 6Q24 12 19 18",
    "fullscreen": "M9 4H4V9M15 4H20V9M20 15V20H15M9 20H4V15",
    "archive": "M3 4H21V9H3Z M5 9V20H19V9M10 13H14"
}
base = Path("design-assets/icons")
runtime = Path("app/src/main/res/drawable")
for name, path in ICONS.items():
    variants = ("", "_filled") if name in ("heart", "profile", "camera", "rooms") else ("",)
    for variant in variants:
        asset = f"momento_ic_{name}{variant}"
        fill = "#162f52" if variant else "none"
        (base / f"{asset}.svg").write_text(
            f'<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">\n'
            f'  <path fill="{fill}" fill-rule="evenodd" stroke="#162f52" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" d="{path}"/>\n</svg>\n'
        )
        android_fill = "#FF162F52" if variant else "#00000000"
        (runtime / f"{asset}.xml").write_text(
            '<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">\n'
            f'    <path android:pathData="{path}" android:fillColor="{android_fill}" android:fillType="evenOdd" android:strokeColor="#FF162F52" android:strokeWidth="1.8" android:strokeLineCap="round" android:strokeLineJoin="round" />\n</vector>\n'
        )
