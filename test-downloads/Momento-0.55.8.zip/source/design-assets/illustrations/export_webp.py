"""Crop transparent padding and export runtime WebP. Run from repository root."""
from pathlib import Path
from PIL import Image

source = Path("design-assets/illustrations")
target = Path("app/src/main/res/drawable-nodpi")
target.mkdir(parents=True, exist_ok=True)
for path in sorted(source.glob("*.png")):
    image = Image.open(path).convert("RGBA")
    box = image.getchannel("A").getbbox()
    if not box:
        raise ValueError(f"Empty render: {path}")
    image = image.crop(box)
    image.thumbnail((320, 320), Image.Resampling.LANCZOS)
    output = target / f"momento_render_{path.stem}.webp"
    image.save(output, quality=86, method=6, exact=True)
    print(output.name, image.size, output.stat().st_size)
