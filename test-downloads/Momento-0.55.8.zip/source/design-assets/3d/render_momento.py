"""Run with blender -b --python design-assets/3d/render_momento.py from repository root."""
import bpy
import math
from pathlib import Path
from mathutils import Vector

ROOT = Path.cwd()
OUTPUT = ROOT / "design-assets/illustrations"
OUTPUT.mkdir(parents=True, exist_ok=True)

def material(name, color):
    result = bpy.data.materials.new(name)
    result.diffuse_color = (*color, 1)
    result.use_nodes = True
    shader = result.node_tree.nodes.get("Principled BSDF")
    shader.inputs["Base Color"].default_value = (*color, 1)
    shader.inputs["Roughness"].default_value = 0.36
    return result

def rounded_box(name, center, size, radius, surface, angle=0):
    bpy.ops.mesh.primitive_cube_add(size=1, location=center)
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bevel = obj.modifiers.new("Rounded edges", "BEVEL")
    bevel.width, bevel.segments = radius, 5
    obj.modifiers.new("Smooth normals", "WEIGHTED_NORMAL")
    obj.rotation_euler.z = math.radians(angle)
    obj.data.materials.append(surface)
    return obj

def sphere(name, center, scale, surface):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=24, ring_count=12, location=center)
    obj = bpy.context.object
    obj.name = name
    obj.scale = scale
    obj.data.materials.append(surface)
    for face in obj.data.polygons:
        face.use_smooth = True

def play(center, surface):
    x, y, z = center
    points = [(-.23,-.31),(.33,0),(-.23,.31)]
    mesh = bpy.data.meshes.new("Play mesh")
    mesh.from_pydata([(x+a,y+b,z+c) for c in (0,.1) for a,b in points], [],
                    [(2,1,0),(3,4,5),(0,1,4,3),(1,2,5,4),(2,0,3,5)])
    mesh.update()
    obj = bpy.data.objects.new("Play mark", mesh)
    bpy.context.collection.objects.link(obj)
    mesh.materials.append(surface)
    bevel = obj.modifiers.new("Rounded edges", "BEVEL")
    bevel.width, bevel.segments = .045, 4

def person(x, y, z, scale, surface):
    sphere("Head", (x, y+.27*scale, z), (.26*scale,.26*scale,.22*scale), surface)
    rounded_box("Shoulders", (x,y-.26*scale,z), (.91*scale,.56*scale,.36*scale), .17*scale, surface)

def aim(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat('-Z','Y').to_euler()

for name in ("save", "share", "people", "subscriptions", "rooms", "reminder", "shield", "error", "offline"):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    blue = material("Cobalt matte", (.012,.19,.74))
    ice = material("Ice blue", (.30,.62,.94))
    pale = material("Pale porcelain", (.75,.88,1))
    white = material("White", (.92,.97,1))
    red = material("Coral matte", (.76,.055,.075))
    if name in ("save", "subscriptions", "share"):
        if name != "subscriptions":
            rounded_box("Rear left memory", (-.75,.22,0), (1.6,1.13,.25), .12, ice, 16)
        rounded_box("Rear memory", (.44,.24,.08), (1.75,1.23,.28), .13, pale, -15)
        rounded_box("Main memory", (0,-.25,.33), (2,1.39,.34), .16, blue)
        if name == "share":
            for x, tone in [(-.5,ice),(0,white),(.5,pale)]:
                person(x,-.23,.56,.48,tone)
        else:
            play((0,-.24,.52), white)
        sphere("Upper left accent", (-1.2,.84,.06), (.13,.13,.13), ice)
        sphere("Upper right accent", (1.2,.72,.16), (.09,.09,.09), blue)
    elif name == "people":
        rounded_box("Porcelain group frame", (0,.03,0), (2.43,1.7,.29), .14, pale, -8)
        person(-.59,.2,.23,.82,ice)
        person(.59,.2,.23,.82,ice)
        person(0,-.18,.48,1.06,blue)
    elif name == "rooms":
        rounded_box("Folder tab", (-.55,.54,0),(1.23,.59,.25),.11,blue)
        rounded_box("Folder back",(0,0,.04),(2.40,1.46,.29),.13,blue)
        rounded_box("Video insert",(.08,.42,.24),(1.63,1.16,.20),.09,pale,-9)
        play((.16,.51,.35), blue)
        rounded_box("Folder front",(0,-.37,.40),(2.38,.75,.27),.13,ice)
    elif name in ("error", "offline"):
        surface = red if name == "error" else ice
        rounded_box("Cloud base",(0,-.34,0),(2.24,.74,.40),.18,surface)
        for x,y,s in [(-.67,.01,.48),(0,.31,.65),(.67,.03,.45)]:
            sphere("Cloud lobe",(x,y,.06),(s,s,.34),surface)
        if name == "error":
            rounded_box("Warning stroke",(0,.21,.44),(.14,.6,.14),.06,white)
            sphere("Warning point",(0,-.23,.46),(.09,.09,.06),white)
        else:
            rounded_box("Connection slash",(0,.07,.45),(1.02,.14,.12),.05,white,-28)
    elif name == "shield":
        rounded_box("Shield tile",(0,0,0),(1.83,1.78,.32),.15,blue)
        for name_part,x,y,length,angle in [("Short",-.22,-.05,.45,-42),("Long",.23,.08,.78,42)]:
            rounded_box(name_part,(x,y,.25),(length,.16,.16),.07,white,angle)
    else:
        rounded_box("Bell tile",(0,0,0),(1.85,1.80,.32),.16,blue)
        sphere("Bell dome",(0,.12,.27),(.43,.44,.22),white)
        rounded_box("Bell lip",(0,-.21,.30),(.94,.18,.24),.075,white)
        sphere("Bell clapper",(0,-.38,.28),(.12,.12,.11),ice)

    bpy.ops.object.camera_add(location=(1.0,-3.0,8.3))
    camera = bpy.context.object
    aim(camera, (0,0,.2))
    camera.data.type = "ORTHO"
    camera.data.ortho_scale = 3.6
    for label,location,power,size in [("Softbox upper left",(-3,2,6),440,4),("Fill",(3,0,5),150,3),("Rim",(-1,-4,4),90,3)]:
        bpy.ops.object.light_add(type="AREA", location=location)
        light = bpy.context.object
        light.name = label
        light.data.energy = power
        light.data.size = size
        aim(light, (0,0,0))
    scene = bpy.context.scene
    scene.camera = camera
    scene.render.engine = "CYCLES"
    scene.cycles.samples = 24
    scene.cycles.use_denoising = False
    scene.render.threads_mode = "FIXED"
    scene.render.threads = 2
    scene.render.resolution_x = scene.render.resolution_y = 384
    scene.render.resolution_percentage = 100
    scene.render.film_transparent = True
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGBA"
    scene.render.filepath = str(OUTPUT / f"{name}.png")
    bpy.context.preferences.filepaths.save_version = 0
    bpy.ops.wm.save_as_mainfile(filepath=str(ROOT / "design-assets/3d" / f"{name}.blend"))
    bpy.ops.render.render(write_still=True)
