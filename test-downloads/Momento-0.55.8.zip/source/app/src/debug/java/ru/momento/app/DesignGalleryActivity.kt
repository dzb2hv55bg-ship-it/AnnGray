package ru.momento.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.momento.app.ui.MomentoBrand
import ru.momento.app.ui.MomentoIllustration
import ru.momento.app.ui.MomentoPrimaryAction
import ru.momento.app.ui.MomentoStatePanel
import ru.momento.app.ui.designsystem.*

class DesignGalleryActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var dark by remember { mutableStateOf(intent.getBooleanExtra("dark", false)) }
            MomentoTheme(forceDark = dark) {
                var selected by remember { mutableIntStateOf(0) }
                var checked by remember { mutableStateOf(true) }
                val assets = R.drawable::class.java.fields.filter { it.name.startsWith("momento_ic_") }.sortedBy { it.name }
                Scaffold(bottomBar = { MomentoTabStrip(selected, true) { selected = it } }) { padding ->
                    LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item {
                            MomentoBrand()
                            Text("Каталог дизайна", style = MaterialTheme.typography.headlineSmall)
                            MomentoSwitch(dark, { dark = it }, "Тёмная тема")
                        }
                        item {
                            MomentoPrimaryAction("Основная кнопка", {})
                            MomentoPrimaryAction("Недоступно", {}, enabled = false)
                            MomentoSegmentedControl(listOf("Мои", "Совместные", "Открытые"), selected.coerceAtMost(2)) { selected = it }
                        }
                        item {
                            MomentoSettingsGroup {
                                MomentoSettingsRow("Напоминания", "Пять раз в день", R.drawable.momento_ic_bell, trailing = {
                                    MomentoSwitch(checked, { checked = it }, "Напоминания")
                                })
                            }
                        }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                                Vlog3DShutterButton(false, false, true, 0f) {}
                                Vlog3DShutterButton(true, false, true, .58f) {}
                            }
                        }
                        item {
                            MomentoStatePanel("Пока нет подписок", "Новые моменты появятся здесь.",
                                illustration = R.drawable.momento_render_subscriptions)
                        }
                        item { MomentoStatePanel("Не удалось загрузить", "Обновление недоступно.", isError = true) }
                        items(assets, key = { it.name }) { field ->
                            val resource = field.getInt(null)
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                MomentoGlyph(resource, null)
                                MomentoGlyph(resource, null, tint = MaterialTheme.colorScheme.primary)
                                MomentoGlyph(resource, null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = .38f))
                                Text(field.name.removePrefix("momento_ic_"))
                            }
                        }
                        item {
                            MomentoIllustration(R.drawable.momento_render_save)
                            MomentoIllustration(R.drawable.momento_render_share)
                            MomentoIllustration(R.drawable.momento_render_people)
                        }
                    }
                }
            }
        }
    }
}
