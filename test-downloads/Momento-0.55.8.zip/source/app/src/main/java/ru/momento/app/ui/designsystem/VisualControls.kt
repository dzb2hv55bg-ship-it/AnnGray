package ru.momento.app.ui.designsystem

import androidx.annotation.DrawableRes
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ru.momento.app.R

internal val navigationLabels = listOf("Камера", "Комнаты", "Подписки", "Профиль")
internal val navigationIdle = listOf(R.drawable.momento_ic_camera, R.drawable.momento_ic_rooms,
    R.drawable.momento_ic_heart, R.drawable.momento_ic_profile)
internal val navigationActive = listOf(R.drawable.momento_ic_camera_filled, R.drawable.momento_ic_rooms_filled,
    R.drawable.momento_ic_heart_filled, R.drawable.momento_ic_profile_filled)

@Composable
internal fun MomentoGlyph(@DrawableRes asset: Int, description: String?, modifier: Modifier = Modifier, tint: Color = MaterialTheme.colorScheme.onSurface) {
    Icon(painterResource(asset), description, modifier.size(MomentoVisual.iconSize), tint = tint)
}

@Composable
internal fun MomentoTabStrip(selected: Int, enabled: Boolean, onSelect: (Int) -> Unit) {
    val palette = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(topStart = MomentoVisual.navigationRadius, topEnd = MomentoVisual.navigationRadius)
    val light = palette.background.luminance() > 0.5f
    Row(
        Modifier.fillMaxWidth().shadow(if (light) 3.dp else 0.dp, shape).clip(shape)
            .background(if (light) palette.surface else palette.surfaceContainer)
            .border(1.dp, palette.outlineVariant.copy(alpha = 0.65f), shape)
            .windowInsetsPadding(WindowInsets.navigationBars.only(WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom))
            .heightIn(min = MomentoVisual.navigationHeight).selectableGroup()
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        navigationLabels.forEachIndexed { index, label ->
            val active = selected == index
            val backdrop by animateColorAsState(if (active) palette.primaryContainer else Color.Transparent,
                tween(MomentoVisual.stateMillis), label = "navigation background")
            val color by animateColorAsState(when {
                active -> palette.primary
                enabled -> palette.onSurface
                else -> palette.onSurfaceVariant.copy(alpha = 0.45f)
            }, tween(MomentoVisual.stateMillis), label = "navigation color")
            Column(
                Modifier.weight(1f).heightIn(min = 56.dp).clip(RoundedCornerShape(17.dp))
                    .background(backdrop)
                    .selectable(active, enabled = enabled, role = Role.Tab) { onSelect(index) }
                    .padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(3.dp, Alignment.CenterVertically)
            ) {
                MomentoGlyph(if (active) navigationActive[index] else navigationIdle[index], null, tint = color)
                Text(label, color = color, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
internal fun MomentoSegmentedControl(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val palette = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().selectableGroup(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        labels.forEachIndexed { index, label ->
            val active = index == selected
            val color by animateColorAsState(if (active) Color.White else palette.onSurface,
                tween(MomentoVisual.stateMillis), label = "segment color")
            Box(Modifier.weight(1f).heightIn(min = 48.dp).clip(CircleShape)
                .background(if (active) MomentoVisual.gradient else Brush.verticalGradient(
                    listOf(palette.surfaceContainerHigh, palette.surfaceContainer)))
                .selectable(active, role = Role.Tab) { onSelect(index) }
                .padding(horizontal = 3.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center) {
                Text(label, color = color, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center)
            }
        }
    }
}

internal fun Modifier.momentoPanel(dark: Boolean, borderColor: Color, surface: Color): Modifier {
    val shape = RoundedCornerShape(MomentoVisual.cardRadius)
    return shadow(if (dark) 0.dp else 2.dp, shape).clip(shape)
        .background(if (dark) MomentoVisual.darkCard else Brush.verticalGradient(listOf(surface, surface)))
        .border(1.dp, borderColor, shape)
}

@Composable
internal fun MomentoSettingsRow(
    title: String,
    subtitle: String? = null,
    @DrawableRes icon: Int,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    val palette = MaterialTheme.colorScheme
    val action = if (onClick != null) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier
    Row(
        Modifier.fillMaxWidth().heightIn(min = 60.dp).then(action).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        MomentoGlyph(icon, null, tint = palette.onSurface)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (!subtitle.isNullOrBlank()) Text(subtitle, style = MaterialTheme.typography.bodySmall,
                color = palette.onSurfaceVariant)
        }
        if (trailing != null) trailing()
        else if (onClick != null) MomentoGlyph(R.drawable.momento_ic_chevron_right, null, tint = palette.onSurfaceVariant)
    }
}

@Composable
internal fun MomentoSettingsGroup(content: @Composable ColumnScope.() -> Unit) {
    val palette = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().momentoPanel(
        palette.background.luminance() < 0.5f, palette.outlineVariant, palette.surface
    ), content = content)
}

@Composable
internal fun MomentoSwitch(checked: Boolean, onChange: (Boolean) -> Unit, label: String) {
    val palette = MaterialTheme.colorScheme
    val track by animateColorAsState(if (checked) BrandBlue else palette.outline.copy(alpha = 0.65f),
        tween(MomentoVisual.stateMillis), label = "switch track")
    val offset by androidx.compose.animation.core.animateDpAsState(if (checked) 22.dp else 3.dp,
        tween(MomentoVisual.stateMillis), label = "switch position")
    Box(Modifier.size(52.dp, 48.dp).semantics { contentDescription = label }
        .toggleable(checked, role = Role.Switch, onValueChange = onChange),
        contentAlignment = Alignment.Center) {
        Box(Modifier.size(46.dp, 26.dp).clip(CircleShape).background(track)) {
            Box(Modifier.align(Alignment.CenterStart).offset(x = offset).size(21.dp)
                .shadow(1.dp, CircleShape).background(Color.White, CircleShape))
        }
    }
}
