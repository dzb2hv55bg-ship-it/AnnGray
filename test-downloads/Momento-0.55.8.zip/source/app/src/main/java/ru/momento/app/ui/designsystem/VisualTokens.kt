package ru.momento.app.ui.designsystem

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

internal object MomentoVisual {
    val gutter = 16.dp
    val cardRadius = 20.dp
    val navigationRadius = 26.dp
    val navigationHeight = 76.dp
    val iconSize = 24.dp
    val recordingSize = 88.dp
    const val stateMillis = 180
    const val pressMillis = 110
    val gradient = Brush.verticalGradient(listOf(Color(0xFF1685FF), Color(0xFF005BE8)))
    val darkCard = Brush.verticalGradient(listOf(Color(0xFF202D45), Color(0xFF162135)))
}
