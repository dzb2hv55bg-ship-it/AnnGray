package ru.momento.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import android.os.SystemClock
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ru.momento.app.R

@Composable
internal fun MomentoIntroduction(onFinish: () -> Unit) {
    var page by rememberSaveable { mutableIntStateOf(-1) }
    val titles = listOf(R.string.intro_record, R.string.intro_room, R.string.intro_film)
    val descriptions = listOf(R.string.intro_record_body, R.string.intro_room_body, R.string.intro_film_body)
    val artwork = listOf(R.drawable.momento_render_save, R.drawable.momento_render_share, R.drawable.momento_render_people)
    val visiblePage = page
    val welcome = visiblePage < 0
    var lastNavigation by remember { mutableLongStateOf(-1_000L) }
    fun navigate(target: Int) {
        val now = SystemClock.elapsedRealtime()
        if (page != visiblePage || now - lastNavigation < 250L) return
        lastNavigation = now
        if (target == titles.size) onFinish() else page = target.coerceIn(-1, titles.lastIndex)
    }
    BackHandler(enabled = !welcome) { navigate(visiblePage - 1) }
    val palette = MaterialTheme.colorScheme
    BoxWithConstraints(Modifier.fillMaxSize().background(Brush.verticalGradient(
        if (welcome) listOf(Color(0xFF0847B6), Color(0xFF176BFF))
        else listOf(palette.background, palette.primaryContainer)
    )).safeDrawingPadding().pointerInput(visiblePage) {
        if (!welcome) {
            var distance = 0f
            detectHorizontalDragGestures(
                onDragStart = { distance = 0f },
                onHorizontalDrag = { _, amount -> distance += amount },
                onDragEnd = {
                    val threshold = 56.dp.toPx()
                    if (distance > threshold && visiblePage > 0) navigate(visiblePage - 1)
                    if (distance < -threshold && visiblePage < titles.lastIndex) navigate(visiblePage + 1)
                }
            )
        }
    }) {
        val illustrationSize = if (maxHeight > 650.dp) 272.dp else 196.dp
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                .heightIn(min = maxHeight).padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(Modifier.height(12.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)) {
                if (welcome) {
                    Icon(painterResource(R.drawable.momento_play_mark), null, Modifier.size(88.dp), tint = Color.Unspecified)
                    Text("MOMENTO", style = MaterialTheme.typography.headlineLarge, color = Color.White)
                    Text(stringResource(R.string.intro_tagline), color = Color.White,
                        style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
                } else {
                    MomentoIllustration(artwork[page], size = illustrationSize)
                    Text(stringResource(titles[page]), style = MaterialTheme.typography.headlineLarge,
                        textAlign = TextAlign.Center)
                    Text(stringResource(descriptions[page]), style = MaterialTheme.typography.bodyLarge,
                        textAlign = TextAlign.Center)
                }
            }
            Column(Modifier.widthIn(max = 440.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!welcome) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    repeat(titles.size) { index ->
                        Box(Modifier.size(8.dp).background(
                            if (index == page) palette.primary else palette.outlineVariant, CircleShape))
                    }
                }
                when {
                    welcome -> Button(onClick = { navigate(0) }, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF0954D9))) {
                        Text(stringResource(R.string.intro_start))
                    }
                    else -> MomentoPrimaryAction(stringResource(if (page == titles.lastIndex) R.string.intro_start else R.string.intro_next),
                        onClick = { navigate(visiblePage + 1) })
                }
                TextButton(onClick = { navigate(titles.size) }) {
                    Text(stringResource(if (welcome) R.string.intro_sign_in else R.string.intro_skip), color = if (welcome) Color.White else palette.primary)
                }
            }
        }
    }
}
