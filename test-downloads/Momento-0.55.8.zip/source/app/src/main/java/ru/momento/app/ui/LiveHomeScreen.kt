package ru.momento.app.ui

import ru.momento.app.ui.designsystem.MomentoSegmentedControl
import ru.momento.app.ui.designsystem.MomentoGlyph
import ru.momento.app.ui.designsystem.momentoPanel
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import ru.momento.app.data.LocalMoment
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import ru.momento.app.R
import ru.momento.app.data.LocalSpace
import ru.momento.app.network.MomentoApiClient
import ru.momento.app.network.RemoteSpace

@Composable
internal fun LiveHomeScreen(
    rooms: List<LocalSpace>,
    roomMoments: Map<String, List<LocalMoment>>,
    accessToken: String,
    api: MomentoApiClient,
    filter: Int,
    onFilter: (Int) -> Unit,
    onCreate: () -> Unit,
    onSpecialRooms: () -> Unit,
    onOpen: (String) -> Unit,
    onPlay: (String) -> Unit,
    onOpenPublic: (String) -> Unit
) {
    var subscribed by remember(accessToken) { mutableStateOf<Set<String>>(emptySet()) }
    var changing by remember { mutableStateOf<String?>(null) }
    var actionFailed by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var search by rememberSaveable { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    var entries by remember(accessToken) { mutableStateOf<List<RemoteSpace>>(emptyList()) }
    LaunchedEffect(accessToken, filter) {
        if (filter == 2) {
            try {
                val follows = api.getSubscriptions(accessToken).optJSONArray("rooms")
                subscribed = List(follows?.length() ?: 0) { checkNotNull(follows).getJSONObject(it).getString("id") }.toSet()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                actionFailed = true
            }
        }
    }
    LaunchedEffect(filter, search, refresh, accessToken) {
        if (filter != 2) return@LaunchedEffect
        loading = true
        failed = false
        try {
            delay(250)
            entries = api.discoverSpaces(accessToken, search)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            failed = true
        } finally {
            loading = false
        }
    }
    val local = when (filter) {
        0 -> rooms.toList()
        1 -> rooms.filter { it.visibility == "LINK" }
        else -> emptyList()
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Комнаты", style = MaterialTheme.typography.headlineLarge)
                    Text("Ваши влоги и общие моменты", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                FilledIconButton(onClick = onCreate) { Icon(Icons.Default.Add, "Создать комнату") }
            }
        }
        item {
            MomentoSegmentedControl(listOf("Мои", "Совместные", "Открытые"), filter, onFilter)
        }
        if (filter == 1) item {
            MomentoRoomTile("События и секретные комнаты", "Общие воспоминания с близкими",
                "", onClick = onSpecialRooms, icon = Icons.Outlined.Group)
        }
        if (filter == 2) {
            item { OutlinedTextField(search, { search = it.take(100) }, Modifier.fillMaxWidth(),
                singleLine = true, label = { Text("Поиск открытых комнат") }) }
            if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
            if (failed) item { MomentoStatePanel("Не удалось загрузить комнаты", "Проверь подключение к интернету.",
                "Повторить", { refresh++ }, isError = true) }
            if (!failed && !loading && entries.isEmpty()) item {
                MomentoStatePanel("Открытых комнат пока нет", "Попробуй изменить запрос.",
                    illustration = R.drawable.momento_render_rooms)
            }
            if (actionFailed) item { Text("Не удалось обновить подписку.", color = MaterialTheme.colorScheme.error) }
            if (!failed && !loading) items(entries.distinctBy { it.id }, key = { it.id }) { room ->
                MomentoRoomTile(room.name, room.description, "Открытая комната", onClick = { onOpenPublic(room.id) },
                    icon = Icons.Outlined.Language)
                TextButton(enabled = changing == null, onClick = {
                    changing = room.id
                    actionFailed = false
                    val follow = room.id !in subscribed
                    scope.launch {
                        try {
                            api.setRoomFollow(accessToken, room.id, follow)
                            subscribed = if (follow) subscribed + room.id else subscribed - room.id
                        } catch (cancelled: CancellationException) {
                            throw cancelled
                        } catch (_: Exception) {
                            actionFailed = true
                        } finally { changing = null }
                    }
                }) { Text(if (room.id in subscribed) "Отписаться" else "Подписаться") }
            }
        } else {
            if (local.isEmpty() && filter == 0) item {
                MomentoStatePanel("Пока нет комнат", "Создай первую комнату для своих воспоминаний.",
                    illustration = R.drawable.momento_render_rooms)
            }
            items(local, key = { it.id }) { room ->
                val (label, icon) = when (room.visibility) {
                    "PUBLIC" -> "Открытая" to Icons.Outlined.Language
                    "LINK" -> "Совместная" to Icons.Outlined.Group
                    else -> "Личная" to Icons.Outlined.Lock
                }
                val moments = roomMoments[room.id]
                LocalRoomCoverCard(room.name, label, icon, moments,
                    onOpen = { onOpen(room.id) },
                    onPlay = { onPlay(room.id) }.takeIf { !moments.isNullOrEmpty() })
            }
            item {
                OutlinedCard(onClick = onCreate, modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(20.dp)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(48.dp).background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center) { MomentoGlyph(R.drawable.momento_ic_folder_plus, null, tint = MaterialTheme.colorScheme.primary) }
                        Column(Modifier.weight(1f)) {
                            Text("Создать комнату", style = MaterialTheme.typography.titleMedium)
                            Text("Новый влог для ваших моментов", style = MaterialTheme.typography.bodyMedium)
                        }
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null)
                    }
                }
            }
        }
    }
}

@Composable
fun SubscriptionsPlaceholderScreen() {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Подписки", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Здесь появятся продолжения влогов после подключения сервера и авторизации подписок.")
        Text("Пока публичные комнаты не загружены. Личные комнаты других пользователей недоступны.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun LocalRoomCoverCard(
    title: String, label: String, icon: ImageVector, moments: List<LocalMoment>?,
    onOpen: () -> Unit, onPlay: (() -> Unit)?
) {
    val latest = moments?.maxByOrNull { it.capturedAtMillis }
    val frame = rememberMomentFrame(latest?.localPath)
    var menu by remember { mutableStateOf(false) }
    val palette = MaterialTheme.colorScheme
    Card(onClick = onOpen, shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().momentoPanel(palette.background.luminance() < 0.5f,
            palette.outlineVariant, palette.surface),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(84.dp).clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.primaryContainer)) {
                if (frame != null) Image(frame, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Image(painterResource(R.drawable.momento_render_rooms), null, Modifier.fillMaxSize())
                if (latest != null && onPlay != null) {
                    Surface(onClick = onPlay, modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp)
                        .heightIn(min = 48.dp).widthIn(min = 48.dp),
                        shape = CircleShape, color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f)) {
                        Row(Modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center) {
                            Icon(Icons.Default.PlayArrow, "Смотреть влог", Modifier.size(16.dp))
                            Text("0:%02d".format(latest.durationMillis / 1000), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(icon, null, Modifier.size(16.dp))
                    Text(label, style = MaterialTheme.typography.bodyMedium)
                }
                moments?.let {
                    Text(pluralStringResource(R.plurals.room_moment_count, it.size, it.size),
                        style = MaterialTheme.typography.labelMedium)
                }
            }
            Box {
                IconButton(onClick = { menu = true }) { MomentoGlyph(R.drawable.momento_ic_more, "Действия комнаты") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Открыть комнату") }, onClick = { menu = false; onOpen() })
                    if (onPlay != null) DropdownMenuItem(text = { Text("Смотреть влог") },
                        onClick = { menu = false; onPlay() })
                }
            }
        }
    }
}
