package ru.momento.app.ui.designsystem

import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import ru.momento.app.R
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

@Composable
internal fun Vlog3DGlassCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier.vlogGlass(MaterialTheme.shapes.medium, material = MaterialTheme.colorScheme.surfaceContainer)) {
        content()
    }
}

@Composable
internal fun Vlog3DButton(
    onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true,
    content: @Composable () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f, tween(MomentoVisual.pressMillis), label = "button depth")
    val material = MaterialTheme.colorScheme
    Button(
        onClick = onClick,
        modifier = modifier.scale(scale).clip(CircleShape)
            .background(if (enabled) MomentoVisual.gradient else Brush.verticalGradient(
                listOf(material.surfaceContainerHigh, material.surfaceContainer)))
            .border(1.dp, Color.White.copy(alpha = 0.24f), CircleShape),
        enabled = enabled, interactionSource = interaction,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent, disabledContainerColor = Color.Transparent,
            contentColor = Color.White, disabledContentColor = material.onSurfaceVariant
        ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp)
    ) { content() }
}

@Composable
internal fun Vlog3DIconButton(
    onClick: () -> Unit, description: String, modifier: Modifier = Modifier,
    enabled: Boolean = true, haptic: Boolean = true, content: @Composable () -> Unit
) {
    val view = LocalView.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.94f else 1f, label = "icon depth")
    IconButton(
        onClick = {
            if (haptic) view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
            onClick()
        },
        modifier = modifier.scale(scale).vlogGlass(depth = if (pressed) 2.dp else 8.dp)
            .semantics { contentDescription = description },
        interactionSource = interaction, enabled = enabled
    ) { content() }
}

@Composable
internal fun Vlog3DShutterButton(
    busy: Boolean, paused: Boolean, enabled: Boolean, progress: Float, onClick: () -> Unit
) {
    val diameter by animateDpAsState(if (busy) 28.dp else 58.dp, label = "shutter size")
    val corner by animateDpAsState(if (busy) 8.dp else 30.dp, label = "shutter shape")
    val core = when {
        paused -> Color(0xFF965250)
        busy -> CameraRecordAccent
        enabled -> BrandBlue
        else -> Color(0xFF51698D)
    }
    Box(Modifier.size(MomentoVisual.recordingSize), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(2.dp)) {
            val stroke = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            val radius = size.minDimension / 2f - stroke.width / 2f
            drawCircle(Color(0xEFFFFFFF), radius = radius, style = stroke)
            if (progress > 0f) {
                val inset = stroke.width / 2f
                drawArc(BrandBlue, startAngle = -90f, sweepAngle = progress.coerceIn(0f, 1f) * 360f,
                    useCenter = false, topLeft = androidx.compose.ui.geometry.Offset(inset, inset),
                    size = androidx.compose.ui.geometry.Size(size.width - stroke.width, size.height - stroke.width),
                    style = stroke)
            }
        }
        Vlog3DIconButton(
            onClick = onClick, description = if (busy) "Завершить запись" else "Записать момент",
            modifier = Modifier.size(72.dp), enabled = enabled, haptic = false
        ) {
            Box(Modifier.fillMaxSize().background(if (busy) Color.White else Color.Transparent),
                contentAlignment = Alignment.Center) {
                Box(Modifier.size(diameter).clip(RoundedCornerShape(corner)).background(core),
                    contentAlignment = Alignment.Center) {
                    if (!busy) MomentoGlyph(R.drawable.momento_ic_video, null, tint = Color.White)
                }
            }
        }
    }
}

@Composable
internal fun Vlog3DAudioBar(level: Float) {
    LinearProgressIndicator(
        progress = { level }, modifier = Modifier.size(width = 98.dp, height = 9.dp).vlogGlass()
            .semantics { contentDescription = "Уровень микрофона" },
        color = CameraRecordAccent, trackColor = Color(0x991C1F26)
    )
}
