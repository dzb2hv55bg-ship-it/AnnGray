package ru.momento.app.ui

import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import ru.momento.app.R
import ru.momento.app.data.LocalMoment
import ru.momento.app.ui.designsystem.MomentoGlyph
import ru.momento.app.ui.designsystem.MomentoSegmentedControl
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import java.util.Locale

@Composable
fun LifeCalendarScreen(moments: List<LocalMoment>) {
    var period by rememberSaveable { mutableIntStateOf(1) }
    val today = LocalDate.now()
    var cursorEpoch by rememberSaveable { mutableLongStateOf(today.toEpochDay()) }
    var selectedEpoch by rememberSaveable { mutableStateOf<Long?>(null) }
    var previewId by rememberSaveable { mutableStateOf<String?>(null) }
    val cursor = LocalDate.ofEpochDay(cursorEpoch)
    val month = YearMonth.from(cursor)
    val zone = ZoneId.systemDefault()
    val snapshot = moments.toList()
    val groups = remember(snapshot, zone) {
        snapshot.groupBy { Instant.ofEpochMilli(it.capturedAtMillis).atZone(zone).toLocalDate() }
    }
    val start = if (period == 1) month.atDay(1) else cursor.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    val firstCell = start.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    val lastCell = if (period == 1) month.atEndOfMonth().with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY))
        else firstCell.plusDays(6)
    val selected = selectedEpoch?.let(LocalDate::ofEpochDay)
    val visible = when {
        selected != null -> groups[selected].orEmpty()
        period == 0 -> snapshot
        else -> groups.filterKeys { it >= start && it <= lastCell && (period != 1 || YearMonth.from(it) == month) }
            .values.flatten()
    }.sortedByDescending { it.capturedAtMillis }
    val title = remember { DateTimeFormatter.ofPattern("LLLL yyyy", Locale.forLanguageTag("ru")) }
    val preview = visible.firstOrNull { it.id == previewId }
    if (preview != null) CalendarMomentPreview(preview) { previewId = null }

    LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Календарь жизни", style = MaterialTheme.typography.headlineSmall)
                MomentoSegmentedControl(listOf("Всё время", "Месяц", "Неделя"), period) {
                    period = it
                    selectedEpoch = null
                }
                if (period != 0) {
                    val dates = generateSequence(firstCell) { it.plusDays(1).takeIf { next -> next <= lastCell } }.toList()
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = {
                            cursorEpoch = (if (period == 1) cursor.minusMonths(1) else cursor.minusWeeks(1)).toEpochDay()
                            selectedEpoch = null
                        }) { MomentoGlyph(R.drawable.momento_ic_back, "Предыдущий период") }
                        Text(cursor.format(title).replaceFirstChar { it.uppercase() },
                            Modifier.weight(1f), style = MaterialTheme.typography.titleMedium,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        val next = if (period == 1) month.plusMonths(1).atDay(1) else firstCell.plusWeeks(1)
                        IconButton(enabled = next <= today, onClick = {
                            cursorEpoch = next.toEpochDay()
                            selectedEpoch = null
                        }) { MomentoGlyph(R.drawable.momento_ic_chevron_right, "Следующий период") }
                    }
                    Row {
                        listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс").forEach {
                            Text(it, Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    dates.chunked(7).forEach { week ->
                        Row {
                            week.forEach { day ->
                                val inMonth = period != 1 || YearMonth.from(day) == month
                                val active = day == selected
                                Box(Modifier.weight(1f).heightIn(min = 48.dp)
                                    .semantics { contentDescription = day.toString() }
                                    .clickable(enabled = inMonth && day <= today) {
                                        selectedEpoch = if (active) null else day.toEpochDay()
                                    },
                                    contentAlignment = Alignment.Center) {
                                    Column(Modifier.clip(CircleShape).background(when {
                                        active -> MaterialTheme.colorScheme.primary
                                        day == today -> MaterialTheme.colorScheme.primaryContainer
                                        else -> androidx.compose.ui.graphics.Color.Transparent
                                    }).padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(day.dayOfMonth.toString(), color = when {
                                            active -> MaterialTheme.colorScheme.onPrimary
                                            inMonth -> MaterialTheme.colorScheme.onSurface
                                            else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f)
                                        }, style = MaterialTheme.typography.labelMedium)
                                        if (day in groups) Box(Modifier.size(4.dp).background(
                                            if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary, CircleShape))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (visible.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) {
            MomentoStatePanel("В выбранном периоде пока нет моментов", "Здесь появятся записи из личного архива.",
                illustration = R.drawable.momento_render_save)
        }
        items(visible, key = { it.id }) { moment ->
            val image = rememberMomentFrame(moment.localPath)
            Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.primaryContainer)
                .clickable { previewId = moment.id }, contentAlignment = Alignment.Center) {
                if (image != null) Image(image, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)) {
                    MomentoGlyph(R.drawable.momento_ic_play, "Смотреть момент", Modifier.padding(7.dp))
                }
                Surface(Modifier.align(Alignment.BottomEnd).padding(4.dp), shape = RoundedCornerShape(6.dp)) {
                    Text("0:%02d".format(moment.durationMillis / 1000), Modifier.padding(horizontal = 4.dp),
                        style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun CalendarMomentPreview(moment: LocalMoment, onClose: () -> Unit) {
    val context = LocalContext.current
    val player = remember(moment.id) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(moment.file)))
            prepare()
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    Dialog(onDismissRequest = onClose) {
        Surface(shape = RoundedCornerShape(22.dp)) {
            Column {
                AndroidView(factory = { view -> PlayerView(view).apply { this.player = player } },
                    modifier = Modifier.fillMaxWidth().height(300.dp))
                TextButton(onClick = onClose) { Text("Закрыть") }
            }
        }
    }
}
