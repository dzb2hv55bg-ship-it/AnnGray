package ru.momento.app.ui.designsystem

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import ru.momento.app.R

@Composable
internal fun MomentoVideoSurface(
    player: ExoPlayer,
    modifier: Modifier = Modifier,
    playing: Boolean,
    onToggle: () -> Unit,
    fullscreen: Boolean,
    onFullscreen: () -> Unit
) {
    var duration by remember(player) { mutableLongStateOf(0) }
    var position by remember(player) { mutableLongStateOf(0) }
    var pendingSeek by remember(player) { mutableStateOf<Float?>(null) }
    LaunchedEffect(player) {
        while (true) {
            duration = player.duration.coerceAtLeast(0)
            position = player.currentPosition.coerceIn(0, duration)
            delay(if (player.isPlaying) 150 else 400)
        }
    }
    fun time(value: Long): String = "${value / 60_000}:" + "%02d".format(value / 1000 % 60)
    Box(modifier.clip(RoundedCornerShape(20.dp)).background(CameraBackground)) {
        AndroidView(factory = { context ->
            PlayerView(context).apply {
                useController = false
                this.player = player
            }
        }, update = { it.player = player }, modifier = Modifier.fillMaxSize())
        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(
                Brush.verticalGradient(listOf(Color.Transparent, Color(0xE00B1220)))
            ).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onToggle) {
                MomentoGlyph(if (playing) R.drawable.momento_ic_pause else R.drawable.momento_ic_play,
                    if (playing) "Пауза" else "Воспроизвести", tint = Color.White)
            }
            Slider(
                value = pendingSeek ?: position.toFloat(),
                onValueChange = { pendingSeek = it },
                onValueChangeFinished = {
                    pendingSeek?.let { player.seekTo(it.toLong().coerceIn(0, duration)) }
                    pendingSeek = null
                },
                valueRange = 0f..duration.coerceAtLeast(1L).toFloat(),
                enabled = duration > 0,
                modifier = Modifier.weight(1f).semantics { contentDescription = "Позиция видео" },
                colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White,
                    inactiveTrackColor = Color.White.copy(alpha = 0.3f))
            )
            Text("${time((pendingSeek?.toLong() ?: position).coerceAtMost(duration))} / ${time(duration)}",
                Modifier.padding(start = 6.dp), color = Color.White, style = MaterialTheme.typography.labelSmall)
            IconButton(onClick = onFullscreen) {
                MomentoGlyph(R.drawable.momento_ic_fullscreen,
                    if (fullscreen) "Выйти из полноэкранного режима" else "Полноэкранный режим", tint = Color.White)
            }
        }
    }
}
