package ru.momento.app.ui

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import ru.momento.app.BuildConfig
import ru.momento.app.R
import ru.momento.app.ui.designsystem.Vlog3DGlassCard
import ru.momento.app.ui.designsystem.VlogThemeSetting
import ru.momento.app.ui.designsystem.MomentoSettingsGroup
import ru.momento.app.ui.designsystem.MomentoSettingsRow
import ru.momento.app.ui.designsystem.MomentoSwitch
import ru.momento.app.ui.designsystem.MomentoGlyph

internal fun playbackPreferences(context: Context) = context.getSharedPreferences("momento_playback", Context.MODE_PRIVATE)

private enum class SettingsPage { HOME, APPEARANCE, PRIVACY, PLAYBACK, REMINDERS, ABOUT }

@Composable
internal fun MomentoSettings(
    onBack: () -> Unit,
    onSubscriptions: (() -> Unit)? = null,
    reminders: (@Composable () -> Unit)? = null
) {
    val context = LocalContext.current
    val prefs = remember(context) { playbackPreferences(context) }
    var page by rememberSaveable { mutableStateOf(SettingsPage.HOME) }
    fun back() { if (page == SettingsPage.HOME) onBack() else page = SettingsPage.HOME }
    BackHandler { back() }
    val title = when (page) {
        SettingsPage.HOME -> "Настройки"
        SettingsPage.APPEARANCE -> "Внешний вид"
        SettingsPage.PRIVACY -> "Приватность"
        SettingsPage.PLAYBACK -> "Воспроизведение"
        SettingsPage.REMINDERS -> "Напоминания"
        SettingsPage.ABOUT -> "О приложении"
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            IconButton(onClick = ::back) { MomentoGlyph(R.drawable.momento_ic_back, "Назад") }
            Text(title, style = MaterialTheme.typography.headlineSmall)
        }
        when (page) {
            SettingsPage.HOME -> {
                MomentoSettingsGroup {
                    if (reminders != null) MomentoSettingsRow("Напоминания", "5 раз в день, 09:00–21:00",
                        R.drawable.momento_ic_bell, onClick = { page = SettingsPage.REMINDERS })
                    MomentoSettingsRow("Приватность", "Кто видит ваши комнаты", R.drawable.momento_ic_shield,
                        onClick = { page = SettingsPage.PRIVACY })
                    MomentoSettingsRow("Воспроизведение", "Автопродолжение и звук", R.drawable.momento_ic_play,
                        onClick = { page = SettingsPage.PLAYBACK })
                    if (onSubscriptions != null) MomentoSettingsRow("Подписки", "Комнаты и авторы",
                        R.drawable.momento_ic_heart, onClick = onSubscriptions)
                }
                Text("Приложение", style = MaterialTheme.typography.titleMedium)
                MomentoSettingsGroup {
                    MomentoSettingsRow("Тема", "Светлая, тёмная или системная", R.drawable.momento_ic_moon,
                        onClick = { page = SettingsPage.APPEARANCE })
                    HorizontalDivider(Modifier.padding(horizontal = 12.dp))
                    MomentoSettingsRow("О приложении", "Версия ${BuildConfig.VERSION_NAME}", R.drawable.momento_ic_info,
                        onClick = { page = SettingsPage.ABOUT })
                }
                MomentoSettingsGroup {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        MomentoBrand()
                        Text("Живые мини-влоги из твоей реальной жизни", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            SettingsPage.APPEARANCE -> VlogThemeSetting()
            SettingsPage.REMINDERS -> reminders?.invoke()
            SettingsPage.ABOUT -> {
                MomentoBrand()
                Text("Жизнь состоит из моментов. Сохрани их.")
                Text("Версия ${BuildConfig.VERSION_NAME}")
            }
            SettingsPage.PRIVACY -> {
                MomentoIllustration(R.drawable.momento_render_shield)
                MomentoSectionTitle("Кто видит ваши комнаты и моменты")
                MomentoSettingsGroup {
                    MomentoSettingsRow("Открытые комнаты", "Доступны всем после публикации.", R.drawable.momento_ic_globe)
                    HorizontalDivider(Modifier.padding(horizontal = 12.dp))
                    MomentoSettingsRow("Совместные комнаты", "Доступны участникам с разрешением.", R.drawable.momento_ic_users)
                    HorizontalDivider(Modifier.padding(horizontal = 12.dp))
                    MomentoSettingsRow("Личные комнаты", "Видны только владельцу.", R.drawable.momento_ic_lock)
                    MomentoSettingsRow("События", "Доступ определяют настройки события.", R.drawable.momento_ic_calendar)
                    MomentoSettingsRow("Секретные комнаты", "Доступны только двум участникам.", R.drawable.momento_ic_shield)
                }
            }
            SettingsPage.PLAYBACK -> {
                var autoplay by remember { mutableStateOf(prefs.getBoolean("autoplay", true)) }
                var sound by remember { mutableStateOf(prefs.getBoolean("sound", true)) }
                MomentoIllustration(R.drawable.momento_art_film)
                MomentoSettingsGroup {
                    MomentoSettingsRow("Автопродолжение", "Воспроизводить следующий момент",
                        R.drawable.momento_ic_refresh, trailing = {
                            MomentoSwitch(autoplay, {
                                autoplay = it
                                prefs.edit().putBoolean("autoplay", it).apply()
                            }, "Автопродолжение")
                        })
                    HorizontalDivider(Modifier.padding(horizontal = 12.dp))
                    MomentoSettingsRow("Звук по умолчанию", icon = R.drawable.momento_ic_volume, trailing = {
                        MomentoSwitch(sound, {
                            sound = it
                            prefs.edit().putBoolean("sound", it).apply()
                        }, "Звук по умолчанию")
                    })
                }
            }
        }
    }
}
