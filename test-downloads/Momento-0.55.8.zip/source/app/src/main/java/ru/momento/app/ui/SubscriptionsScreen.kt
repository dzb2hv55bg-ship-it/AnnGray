package ru.momento.app.ui

import ru.momento.app.ui.designsystem.Vlog3DGlassCard
import ru.momento.app.ui.designsystem.MomentoSegmentedControl
import androidx.compose.foundation.layout.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.runtime.DisposableEffect
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import ru.momento.app.network.MomentoApiException
import java.io.File
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.key
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import org.json.JSONObject
import ru.momento.app.network.MomentoApiClient
import ru.momento.app.network.RemoteSpace
import ru.momento.app.network.RemoteMoment

private data class FollowedRoom(val id: String, val name: String, val author: String)
private data class FollowedUpdate(val spaceId: String, val roomName: String, val momentId: String, val author: String)
private data class FollowedAuthor(val id: String, val name: String)

@Composable
fun SubscriptionsScreen(
    accessToken: String,
    api: MomentoApiClient,
    onOpenRoom: (String) -> Unit,
    onFindRooms: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var tab by androidx.compose.runtime.saveable.rememberSaveable { mutableIntStateOf(0) }
    var showAuthors by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var followed by remember(accessToken) { mutableStateOf<List<FollowedRoom>>(emptyList()) }
    var authors by remember(accessToken) { mutableStateOf<List<FollowedAuthor>>(emptyList()) }
    var updates by remember(accessToken) { mutableStateOf<List<FollowedUpdate>>(emptyList()) }
    var refreshKey by remember { mutableIntStateOf(0) }
    var pending by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(accessToken, refreshKey) {
        loading = true
        error = null
        try {
            val subscriptions = api.getSubscriptions(accessToken)
            val roomList = subscriptions.optJSONArray("rooms")
            val authorList = subscriptions.optJSONArray("authors")
            val news = api.getSubscriptionUpdates(accessToken).optJSONArray("items")
            followed = List(roomList?.length() ?: 0) { index ->
                val item = checkNotNull(roomList).getJSONObject(index)
                FollowedRoom(item.getString("id"), item.getString("name"), item.optString("author_name"))
            }
            authors = List(authorList?.length() ?: 0) { index ->
                val item = checkNotNull(authorList).getJSONObject(index)
                FollowedAuthor(item.getString("id"), item.optString("display_name").ifBlank { "Автор" })
            }
            updates = List(news?.length() ?: 0) { index ->
                val item = checkNotNull(news).getJSONObject(index)
                FollowedUpdate(item.getString("space_id"), item.getString("room_name"),
                    item.getString("moment_id"), item.optString("author_name"))
            }.distinctBy { it.momentId }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            error = "Проверь подключение к интернету и попробуй снова."
        } finally { loading = false }
    }
    fun unfollow(id: String, author: Boolean) {
        if (pending != null) return
        pending = id
        scope.launch {
            try {
                if (author) api.setAuthorFollow(accessToken, id, false)
                else api.setRoomFollow(accessToken, id, false)
                refreshKey++
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                error = "Проверь подключение к интернету и попробуй снова."
            } finally { pending = null }
        }
    }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()) {
        item { MomentoSectionTitle("Подписки") }
        item {
            MomentoSegmentedControl(listOf("Обновления", "Мои подписки"), tab) { tab = it }
        }
        if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        error?.let { message ->
            item { MomentoStatePanel("Не удалось обновить подписки", message, "Повторить",
                { refreshKey++ }, isError = true) }
        }
        if (error == null && !loading) {
            if (tab == 0) {
                if (updates.isEmpty()) item {
                    MomentoStatePanel("Пока нет новых моментов", "Здесь появятся новые записи из твоих подписок.",
                        "Найти комнаты", onFindRooms, illustration = ru.momento.app.R.drawable.momento_render_subscriptions)
                }
                items(updates, key = { it.momentId }) { update ->
                    MomentoRoomTile(update.roomName, update.author, "Новый момент", { onOpenRoom(update.spaceId) })
                }
            } else {
                item {
                    MomentoSegmentedControl(listOf("Комнаты", "Авторы"), if (showAuthors) 1 else 0) {
                        showAuthors = it == 1
                    }
                }
                if (showAuthors) {
                    if (authors.isEmpty()) item { MomentoStatePanel("Пока нет подписок на авторов", "Найди истории в открытых комнатах.", "Найти комнаты", onFindRooms) }
                    items(authors, key = { it.id }) { author ->
                        ListItem(headlineContent = { Text(author.name) }, trailingContent = {
                            TextButton(enabled = pending == null, onClick = { unfollow(author.id, true) }) { Text("Отписаться") }
                        })
                    }
                } else {
                    if (followed.isEmpty()) item { MomentoStatePanel("Пока нет подписок", "Подпишись на интересные комнаты.", "Найти комнаты", onFindRooms, illustration = ru.momento.app.R.drawable.momento_render_subscriptions) }
                    items(followed, key = { it.id }) { room ->
                        Vlog3DGlassCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text(room.name, style = MaterialTheme.typography.titleMedium)
                                Text(room.author)
                                Row {
                                    TextButton(onClick = { onOpenRoom(room.id) }) { Text("Смотреть") }
                                    TextButton(enabled = pending == null, onClick = { unfollow(room.id, false) }) { Text("Отписаться") }
                                }
                            }
                        }
                    }
                }
            }
            item { TextButton(onClick = { refreshKey++ }) { Text("Обновить") } }
        }
    }
}

@Composable
fun PublicRoomScreen(
    accessToken: String, roomId: String, api: MomentoApiClient,
    sharedRoom: Boolean = false, onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var roomName by remember(roomId, accessToken) { mutableStateOf<String?>(null) }
    var publicAuthor by remember(roomId, accessToken) { mutableStateOf<Pair<String, String>?>(null) }
    var followingAuthor by remember(roomId, accessToken) { mutableStateOf(false) }
    var authorBusy by remember(roomId, accessToken) { mutableStateOf(false) }
    var authorError by remember(roomId, accessToken) { mutableStateOf(false) }
    LaunchedEffect(roomId, accessToken, sharedRoom) {
        if (accessToken.isBlank()) return@LaunchedEffect
        try {
            val details = api.specialRoomDetails(accessToken, roomId)
            roomName = details.optString("name").ifBlank { null }
            if (!sharedRoom && details.optString("visibility") == "PUBLIC" && !details.isNull("published_at")) {
                val id = details.optString("owner_id")
                if (id.isNotBlank()) {
                    val list = api.getSubscriptions(accessToken).optJSONArray("authors")
                    followingAuthor = (0 until (list?.length() ?: 0))
                        .any { list?.optJSONObject(it)?.optString("id") == id }
                    publicAuthor = id to details.optString("author_name").ifBlank { "Автор" }
                }
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            publicAuthor = null
        }
    }
    androidx.activity.compose.BackHandler(onBack = onBack)
    var moments by remember(roomId) { mutableStateOf<List<RemoteMoment>>(emptyList()) }
    var error by remember(roomId) { mutableStateOf<String?>(null) }
    var loading by remember(roomId) { mutableStateOf(true) }
    var retry by remember(roomId) { mutableIntStateOf(0) }
    var currentIndex by remember(roomId) { mutableIntStateOf(0) }
    val context = LocalContext.current
    var cachedVideo by remember(roomId, accessToken) { mutableStateOf<File?>(null) }
    var paused by remember(roomId) { mutableStateOf(false) }
    val playback = remember(context) { playbackPreferences(context) }
    val autoplay = playback.getBoolean("autoplay", true)
    var muted by remember(roomId) { mutableStateOf(!playback.getBoolean("sound", true)) }
    var videoRetry by remember(roomId) { mutableIntStateOf(0) }
    var videoError by remember(roomId) { mutableStateOf<String?>(null) }
    val playbackFolder = remember(context, roomId) {
        File(context.cacheDir, "room-playback-${java.util.UUID.randomUUID()}").apply { mkdir() }
    }
    val player = remember(context, roomId) { ExoPlayer.Builder(context).build() }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && autoplay && currentIndex < moments.lastIndex) currentIndex++
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                videoError = "Ошибка воспроизведения"
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
            // Server video cache is temporary; never leave private clips on disk after viewing.
            playbackFolder.deleteRecursively()
        }
    }
    LaunchedEffect(paused, muted, player) {
        player.playWhenReady = !paused
        player.volume = if (muted) 0f else 1f
    }

    val selected = moments.getOrNull(currentIndex)
    LaunchedEffect(roomId, selected?.id, accessToken, videoRetry) {
        player.stop(); player.clearMediaItems()
        cachedVideo?.delete()
        cachedVideo = null
        videoError = null
        if (selected == null) return@LaunchedEffect
        val file = File(playbackFolder, "${selected.id}.mp4")
        try {
            // Always reauthorize server videos, including previously cached private videos.
            // Offline playback of private server content is deliberately disabled.
            file.delete()
            cachedVideo = api.downloadMomentVideo(accessToken, selected.id, file)
            player.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
            player.prepare()
            player.playWhenReady = !paused
        }
        catch (e: CancellationException) {
            file.delete()
            throw e
        } catch (e: Exception) {
            videoError = if (e is MomentoApiException && e.statusCode == 401) "Сессия истекла. Войди снова"
                else e.message ?: "Не удалось получить видео"
        }
    }
    LaunchedEffect(roomId, accessToken, retry) {
        loading = true
        do {
            try {
                val page = api.getSpaceTimeline(accessToken, roomId, limit = if (sharedRoom) 50 else 20)
                val updated = page.items.asReversed()
                val currentId = moments.getOrNull(currentIndex)?.id
                val index = updated.indexOfFirst { it.id == currentId }
                currentIndex = index.coerceAtLeast(0)
                moments = updated
                error = null
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (failure: Exception) {
                moments = emptyList()
                currentIndex = 0
                error = failure.message ?: "Ошибка загрузки комнаты"
            } finally {
                loading = false
            }
            if (sharedRoom) delay(15_000)
        } while (sharedRoom)
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onClick = onBack) { Text("Назад") }
        MomentoScreenHeading(roomName ?: "Моменты комнаты")
        if (error == null) publicAuthor?.let { (id, name) ->
            TextButton(enabled = !authorBusy, onClick = {
                authorBusy = true
                authorError = false
                scope.launch {
                    try {
                        val desired = !followingAuthor
                        api.setAuthorFollow(accessToken, id, desired)
                        followingAuthor = desired
                    } catch (cancelled: CancellationException) {
                        throw cancelled
                    } catch (_: Exception) {
                        authorError = true
                    } finally { authorBusy = false }
                }
            }) { Text(if (followingAuthor) "Отписаться от автора" else "Подписаться · $name") }
        }
        if (authorError) Text("Не удалось изменить подписку", color = MaterialTheme.colorScheme.error)
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        error?.let { MomentoStatePanel("Не удалось получить влог", it, "Повторить", { retry++ }, isError = true) }
        if (!loading && error == null) {
            if (moments.isEmpty()) MomentoStatePanel("Пока нет моментов", "В этой комнате ещё нет доступных записей.")
            else {
                val activeMoment = moments[currentIndex.coerceIn(moments.indices)]
                Text("Момент ${currentIndex + 1} из ${moments.size}")
                Text("${activeMoment.capturedAt} · ${activeMoment.authorDisplayName}")
                videoError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                val file = cachedVideo
                if (file != null) {
                    AndroidView(factory = { ctx -> PlayerView(ctx).apply {
                        useController = false
                        this.player = player
                    } }, update = { it.player = player },
                        modifier = Modifier.fillMaxWidth().weight(1f).pointerInput(currentIndex) {
                            var drag = 0f
                            detectHorizontalDragGestures(onHorizontalDrag = { _, dx -> drag += dx }, onDragEnd = {
                                if (drag < -60f && currentIndex < moments.lastIndex) currentIndex++
                                if (drag > 60f && currentIndex > 0) currentIndex--
                                drag = 0f
                            })
                        })
                } else if (videoError == null) CircularProgressIndicator()
                if (videoError != null) TextButton(onClick = { videoRetry++ }) { Text("Повторить загрузку") }
                Row {
                    TextButton(onClick = { paused = !paused }) { Text(if (paused) "Играть" else "Пауза") }
                    TextButton(onClick = { muted = !muted }) { Text(if (muted) "Включить звук" else "Без звука") }
                    TextButton(enabled = currentIndex > 0, onClick = { currentIndex-- }) { Text("Назад") }
                    TextButton(enabled = currentIndex < moments.lastIndex, onClick = { currentIndex++ }) { Text("Следующий") }
                }
            }
        }
    }
}
