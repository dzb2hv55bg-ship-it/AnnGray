package ru.momento.app.ui

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import ru.momento.app.BuildConfig
import ru.momento.app.R
import ru.momento.app.ui.designsystem.Vlog3DGlassCard
import ru.momento.app.ui.designsystem.VlogThemeSetting

internal fun playbackPreferences(context: Context) = context.getSharedPreferences("momento_playback", Context.MODE_PRIVATE)

private enum class SettingsPage { HOME, APPEARANCE, PRIVACY, PLAYBACK, REMINDERS, ABOUT }

@Composable
internal fun MomentoSettings(
    onBack: () -> Unit,
    onSubscriptions: (() -> Unit)? = null,
    reminders: (@Composable () -> Unit)? = null
) {
    val context = LocalContext.current
    val prefs = remember(context) { playbackPreferences(context) }
    var page by rememberSaveable { mutableStateOf(SettingsPage.HOME) }
    fun back() { if (page == SettingsPage.HOME) onBack() else page = SettingsPage.HOME }
    BackHandler { back() }
    val title = when (page) {
        SettingsPage.HOME -> "Настройки"
        SettingsPage.APPEARANCE -> "Внешний вид"
        SettingsPage.PRIVACY -> "Приватность"
        SettingsPage.PLAYBACK -> "Воспроизведение"
        SettingsPage.REMINDERS -> "Напоминания"
        SettingsPage.ABOUT -> "О приложении"
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            IconButton(onClick = ::back) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") }
            Text(title, style = MaterialTheme.typography.headlineSmall)
        }
        when (page) {
            SettingsPage.HOME -> {
                if (reminders != null) MomentoRoomTile("Напоминания", "5 раз в день, 09:00–21:00", "",
                    onClick = { page = SettingsPage.REMINDERS }, icon = Icons.Outlined.Notifications)
                MomentoRoomTile("Приватность", "Кто видит ваши комнаты", "",
                    onClick = { page = SettingsPage.PRIVACY }, icon = Icons.Outlined.Lock)
                MomentoRoomTile("Воспроизведение", "Автопродолжение и звук", "",
                    onClick = { page = SettingsPage.PLAYBACK }, icon = Icons.Outlined.PlayCircle)
                if (onSubscriptions != null) MomentoRoomTile("Подписки", "Комнаты и авторы", "",
                    onClick = onSubscriptions, icon = Icons.Outlined.FavoriteBorder)
                MomentoRoomTile("Тема", "Светлая, тёмная или системная", "",
                    onClick = { page = SettingsPage.APPEARANCE }, icon = Icons.Outlined.Palette)
                MomentoRoomTile("О приложении", "Версия ${BuildConfig.VERSION_NAME}", "",
                    onClick = { page = SettingsPage.ABOUT }, icon = Icons.Outlined.Info)
            }
            SettingsPage.APPEARANCE -> VlogThemeSetting()
            SettingsPage.REMINDERS -> reminders?.invoke()
            SettingsPage.ABOUT -> {
                MomentoBrand()
                Text("Жизнь состоит из моментов. Сохрани их.")
                Text("Версия ${BuildConfig.VERSION_NAME}")
            }
            SettingsPage.PRIVACY -> {
                MomentoIllustration(R.drawable.momento_art_secret)
                MomentoSectionTitle("Кто видит ваши комнаты и моменты")
                Vlog3DGlassCard(Modifier.fillMaxWidth()) {
                    Column {
                        listOf(
                            "Личные" to "Доступны только владельцу.",
                            "Совместные" to "Доступны участникам, которым предоставлен доступ.",
                            "Открытые" to "Доступны другим пользователям после публикации.",
                            "События" to "Доступ определяют настройки события.",
                            "Секретные" to "Доступны только двум участникам."
                        ).forEach { (type, access) ->
                            ListItem(headlineContent = { Text(type) }, supportingContent = { Text(access) },
                                colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.surfaceContainer))
                        }
                    }
                }
            }
            SettingsPage.PLAYBACK -> {
                var autoplay by remember { mutableStateOf(prefs.getBoolean("autoplay", true)) }
                var sound by remember { mutableStateOf(prefs.getBoolean("sound", true)) }
                MomentoIllustration(R.drawable.momento_art_film)
                ListItem(headlineContent = { Text("Автопродолжение") },
                    supportingContent = { Text("Воспроизводить следующий момент") },
                    trailingContent = { Switch(autoplay, {
                        autoplay = it
                        prefs.edit().putBoolean("autoplay", it).apply()
                    }) })
                ListItem(headlineContent = { Text("Звук по умолчанию") },
                    trailingContent = { Switch(sound, {
                        sound = it
                        prefs.edit().putBoolean("sound", it).apply()
                    }) })
            }
        }
    }
}
