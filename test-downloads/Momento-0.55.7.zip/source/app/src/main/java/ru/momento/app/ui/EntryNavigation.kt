package ru.momento.app.ui

internal enum class EntryRoute { INTRODUCTION, AUTH, GUEST, LOCAL_CAMERA, GUEST_SIGN_IN, GUEST_PUBLISH }

internal fun initialEntryRoute(onboardingComplete: Boolean): EntryRoute =
    if (onboardingComplete) EntryRoute.AUTH else EntryRoute.INTRODUCTION

/** Apply an event only while the origin still owns the displayed screen. */
internal fun moveEntry(current: EntryRoute, origin: EntryRoute, destination: EntryRoute): EntryRoute =
    if (current == origin) destination else current
