package ru.momento.app.ui.designsystem

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF005BE8), onPrimary = Color.White,
    primaryContainer = Color(0xFFDCEAFF), onPrimaryContainer = Color(0xFF142C54),
    background = Color(0xFFF5F8FF), surface = Color.White,
    surfaceContainerLow = Color(0xFFF9FBFF), surfaceContainer = Color(0xFFEDF3FC),
    surfaceContainerHigh = Color(0xFFE4ECF8), outlineVariant = Color(0xFFDCE5F2),
    onSurface = Color(0xFF101827), onSurfaceVariant = Color(0xFF56647A),
    outline = Color(0xFF78859A), error = Color(0xFFB92437)
)
internal val DarkColors = darkColorScheme(
    primary = Color(0xFF75B1FF), onPrimary = Color(0xFF10243E),
    primaryContainer = Color(0xFF1D3C70), onPrimaryContainer = Color(0xFFDCEAFF),
    secondary = Color(0xFFB3BED2), background = Graphite,
    surface = Color(0xFF18243A), surfaceContainerLow = Color(0xFF172335),
    surfaceContainer = Color(0xFF1B293D), surfaceContainerHigh = Color(0xFF203451),
    outlineVariant = Color(0xFF2A3953), onSurface = Color(0xFFF5F7FF),
    onSurfaceVariant = Color(0xFFB3BED2), outline = Color(0xFF8291A9),
    error = Color(0xFFFF8290)
)

private val MomentoTypography = Typography(
    headlineLarge = TextStyle(fontSize = 30.sp, lineHeight = 38.sp, fontWeight = FontWeight.Bold),
    headlineSmall = TextStyle(fontSize = 24.sp, lineHeight = 32.sp, fontWeight = FontWeight.SemiBold),
    titleLarge = TextStyle(fontSize = 21.sp, lineHeight = 27.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 17.sp, lineHeight = 23.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 23.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontSize = 15.sp, lineHeight = 21.sp, fontWeight = FontWeight.SemiBold),
    labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 15.sp, fontWeight = FontWeight.Medium)
)

private val MomentoShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp), small = RoundedCornerShape(16.dp),
    medium = RoundedCornerShape(24.dp), large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

private enum class Appearance(val label: String) {
    SYSTEM("Системная"), LIGHT("Светлая"), DARK("Тёмная")
}

private class ThemeChoice(val appearance: Appearance, val update: (Appearance) -> Unit)
private val LocalThemeChoice = staticCompositionLocalOf<ThemeChoice?> { null }

@Composable
fun MomentoTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val prefs = remember(context) { context.getSharedPreferences("momento_display", 0) }
    var preference by remember(prefs) {
        mutableStateOf(Appearance.entries.firstOrNull { it.name == prefs.getString("appearance", null) }
            ?: if (prefs.contains("dark_theme")) {
                if (prefs.getBoolean("dark_theme", true)) Appearance.DARK else Appearance.LIGHT
            } else Appearance.LIGHT)
    }
    val dark = preference == Appearance.DARK || (preference == Appearance.SYSTEM && isSystemInDarkTheme())
    val choice = ThemeChoice(preference) { selected ->
        preference = selected
        prefs.edit().putString("appearance", selected.name).apply()
    }
    CompositionLocalProvider(LocalThemeChoice provides choice) {
        MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, shapes = MomentoShapes, typography = MomentoTypography) {
            val backdrop = if (dark) {
                Brush.verticalGradient(listOf(GraphiteLight, Graphite))
            } else {
                Brush.verticalGradient(listOf(LightColors.primaryContainer, LightColors.background))
            }
            Box(Modifier.fillMaxSize().background(backdrop)) { content() }
        }
    }
}

@Composable
internal fun VlogThemeSetting() {
    val choice = LocalThemeChoice.current ?: return
    Vlog3DGlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).selectableGroup()) {
            Text("Внешний вид", style = MaterialTheme.typography.titleMedium)
            Appearance.entries.forEach { option ->
                val selected = choice.appearance == option
                Row(
                    Modifier.fillMaxWidth().selectable(selected, role = Role.RadioButton) { choice.update(option) }
                        .padding(vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(option.label, Modifier.weight(1f))
                    RadioButton(selected, onClick = null, modifier = Modifier.padding(horizontal = 12.dp))
                }
            }
        }
    }
}
