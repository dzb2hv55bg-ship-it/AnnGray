package ru.momento.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ru.momento.app.data.LocalSpace

private val topics = listOf("День", "Путешествие", "Событие", "Семья", "Спорт", "Настроение", "Проект", "Другое")

/** Only locally owned rooms are shown. Never misrepresent them as public server listings. */
@Composable
fun RoomsDiscoveryScreen(rooms: List<LocalSpace>, onCreate: () -> Unit, onMine: () -> Unit) {
    var filter by rememberSaveable { mutableStateOf("Для вас") }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Комнаты", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Живые мини-влоги, истории и события", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(16.dp))
            Button(onClick = onCreate, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(50)) {
                Text("＋  Создать комнату")
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Для вас", "Новые", "Подписки").forEach { option ->
                    FilterChip(selected = filter == option, onClick = { filter = option }, label = { Text(option) })
                }
            }
        }
        item {
            Text("Открытые комнаты", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text("Публичный каталог появится после подключения сервера. Мы не показываем чужие личные комнаты.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            OutlinedButton(onClick = onMine, modifier = Modifier.fillMaxWidth()) { Text("Открыть мои комнаты (${rooms.size})") }
        }
    }
}

@Composable
fun MyRoomsScreen(rooms: List<LocalSpace>, onCreate: () -> Unit, onOpen: (String) -> Unit) {
    var filter by rememberSaveable { mutableStateOf("Все") }
    val visible = rooms.filter { filter == "Все" || when (filter) {
        "Черновики" -> it.status == "DRAFT"
        "Личные" -> it.visibility != "PUBLIC"
        else -> it.status == "PUBLISHED"
    } }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Мои комнаты", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Все", "Черновики", "Личные").forEach { option ->
                    FilterChip(selected = filter == option, onClick = { filter = option }, label = { Text(option) })
                }
            }
        }
        if (visible.isEmpty()) item {
            MomentoStatePanel("Комнат пока нет", "Создай комнату, чтобы сохранять живые моменты.")
        }
        items(visible, key = { it.id }) { room -> RoomDraftCard(room, onOpen) }
        item { MomentoPrimaryAction("Создать комнату", onCreate) }
    }
}

@Composable
private fun RoomDraftCard(room: LocalSpace, onOpen: (String) -> Unit) {
    MomentoRoomTile(
        title = room.name,
        description = room.description,
        metadata = "${room.topic} · ${if (room.visibility == "PUBLIC") "Открытая" else if (room.visibility == "LINK") "По ссылке" else "Личная"} · ${if (room.status == "DRAFT") "Черновик" else "Сохранена локально"}",
        onClick = { onOpen(room.id) },
        footer = "Хранится на устройстве. Публикация требует подтверждения сервера."
    )
}

@Composable
fun RoomSearchScreen(rooms: List<LocalSpace>, onOpen: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val matches = remember(query, rooms) {
        rooms.filter { room -> room.name.contains(query, true) || room.description.contains(query, true) || room.topic.contains(query, true) }
    }
    LazyColumn(contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Поиск комнат", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { OutlinedTextField(value = query, onValueChange = { query = it.take(100) }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Название, тема или описание") }, shape = RoundedCornerShape(20.dp)) }
        item { Text("Локальный поиск по моим комнатам", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        if (matches.isEmpty()) item { Text("Ничего не найдено") }
        items(matches, key = { it.id }) { RoomDraftCard(it, onOpen) }
        item { Text("Поиск публичных комнат и авторов требует подключения сервера.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
fun CreateRoomScreen(saving: Boolean, onSave: (String, String, String, String) -> Unit, onCancel: () -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }
    var visibility by rememberSaveable { mutableStateOf("PRIVATE") }
    var topic by rememberSaveable { mutableStateOf("День") }
    var confirmExit by rememberSaveable { mutableStateOf(false) }
    fun back() {
        if (!saving) {
            if (name.isNotBlank() || description.isNotBlank()) confirmExit = true else onCancel()
        }
    }
    androidx.activity.compose.BackHandler { back() }
    if (confirmExit) AlertDialog(
        onDismissRequest = { confirmExit = false },
        title = { Text("Выйти без сохранения?") },
        text = { Text("Введённые название и описание не сохранятся.") },
        confirmButton = { TextButton(onClick = onCancel) { Text("Выйти") } },
        dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Продолжить редактирование") } }
    )
    LazyColumn(
        modifier = Modifier.fillMaxWidth().imePadding(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            TextButton(onClick = ::back, enabled = !saving) { Text("Назад") }
            MomentoSectionTitle("Создать комнату")
        }
        item {
            Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.primaryContainer) {
                androidx.compose.foundation.layout.Box(Modifier.heightIn(min = 140.dp),
                    contentAlignment = androidx.compose.ui.Alignment.Center) {
                    MomentoIllustration(ru.momento.app.R.drawable.momento_art_rooms)
                }
            }
        }
        item { OutlinedTextField(name, { name = it.take(60) }, Modifier.fillMaxWidth(),
            label = { Text("Название комнаты") }, placeholder = { Text("Например, Мой день") },
            enabled = !saving, shape = RoundedCornerShape(14.dp), singleLine = true) }
        item { OutlinedTextField(description, { description = it.take(500) }, Modifier.fillMaxWidth(),
            label = { Text("Описание (необязательно)") }, enabled = !saving, shape = RoundedCornerShape(14.dp)) }
        item { MomentoSectionTitle("Видимость") }
        item {
            Column(Modifier.selectableGroup(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    Triple("PRIVATE", "Личная", "Видна только тебе"),
                    Triple("LINK", "Совместная", "По ссылке и приглашению"),
                    Triple("PUBLIC", "Открытая", "Доступна всем после публикации")
                ).forEach { (value, title, detail) ->
                    val selected = visibility == value
                    Surface(shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface) {
                        Row(
                            Modifier.fillMaxWidth().selectable(selected, enabled = !saving, role = Role.RadioButton) { visibility = value }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                        ) {
                            RadioButton(selected, onClick = null)
                            Column {
                                Text(title, style = MaterialTheme.typography.titleMedium)
                                Text(detail, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }
        item {
            MomentoSectionTitle("Тема комнаты")
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                topics.chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { value -> FilterChip(topic == value, { topic = value }, label = { Text(value) }, enabled = !saving) }
                    }
                }
            }
        }
        item {
            MomentoPrimaryAction(if (saving) "Создаём комнату…" else "Создать",
                onClick = { onSave(name.trim(), description.trim(), visibility, topic) },
                enabled = !saving && name.isNotBlank())
        }
    }
}
