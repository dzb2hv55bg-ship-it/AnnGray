package ru.momento.app

import org.junit.Assert.assertEquals
import org.junit.Test
import ru.momento.app.ui.EntryRoute
import ru.momento.app.ui.initialEntryRoute
import ru.momento.app.ui.moveEntry

class EntryNavigationTest {
    @Test fun completedIntroductionIsSkippedOnNextLaunch() {
        assertEquals(EntryRoute.INTRODUCTION, initialEntryRoute(false))
        assertEquals(EntryRoute.AUTH, initialEntryRoute(true))
    }

    @Test fun rapidTapsFromRemovedScreenCannotChangeCurrentRoute() {
        var route = moveEntry(EntryRoute.INTRODUCTION, EntryRoute.INTRODUCTION, EntryRoute.AUTH)
        repeat(10) { route = moveEntry(route, EntryRoute.INTRODUCTION, EntryRoute.LOCAL_CAMERA) }
        assertEquals(EntryRoute.AUTH, route)
    }
}
